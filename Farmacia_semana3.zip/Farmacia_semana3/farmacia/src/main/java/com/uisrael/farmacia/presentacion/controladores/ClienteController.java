package com.uisrael.farmacia.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IClienteUseCase;
import com.uisrael.farmacia.presentacion.dto.request.ClienteRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.ClienteResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IClienteDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/cliente")
public class ClienteController {
	 private final IClienteUseCase clienteUseCase;
	    private final IClienteDtoMapper mapper;

	    public ClienteController(IClienteUseCase clienteUseCase, IClienteDtoMapper mapper) {
	        this.clienteUseCase = clienteUseCase;
	        this.mapper = mapper;
	    }

	    @PostMapping
	    @ResponseStatus(HttpStatus.CREATED)
	    public ClienteResponseDto guardar(@Valid @RequestBody ClienteRequestDto clienteRequestDto) {
	        return mapper.toResponseDto(
	                clienteUseCase.guardar(
	                        mapper.toDomain(clienteRequestDto)
	                )
	        );
	    }

	    @GetMapping
	    public List<ClienteResponseDto> listarTodo() {
	        return clienteUseCase.listarTodos()
	                .stream()
	                .map(mapper::toResponseDto)
	                .toList();
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> eliminar(@PathVariable int id) {
	        clienteUseCase.eliminar(id);
	        return ResponseEntity.noContent().build();
	    }
}
