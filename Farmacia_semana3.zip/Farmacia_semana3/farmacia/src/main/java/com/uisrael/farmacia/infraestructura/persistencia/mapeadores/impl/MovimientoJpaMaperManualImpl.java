package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Movimiento;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.MovimientoEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IMovimientoJpaMaper;

@Primary
@Component
public class MovimientoJpaMaperManualImpl implements IMovimientoJpaMaper {

	@Override
	public Movimiento toDomain(MovimientoEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Movimiento(entity.getIdMovimiento(), entity.getIdInventario(), entity.getIdUsuario(), entity.getTipoMovimiento(), entity.getCantidad(), entity.getFechaMovimiento(), entity.getObservacion());
	}

	@Override
	public MovimientoEntity toEntity(Movimiento movimientoPojo) {
		if (movimientoPojo == null) {
			return null;
		}
		MovimientoEntity entity = new MovimientoEntity();
		entity.setIdMovimiento(movimientoPojo.getIdMovimiento());
		entity.setIdInventario(movimientoPojo.getIdInventario());
		entity.setIdUsuario(movimientoPojo.getIdUsuario());
		entity.setTipoMovimiento(movimientoPojo.getTipoMovimiento());
		entity.setCantidad(movimientoPojo.getCantidad());
		entity.setFechaMovimiento(movimientoPojo.getFechaMovimiento());
		entity.setObservacion(movimientoPojo.getObservacion());
		return entity;
	}
}
