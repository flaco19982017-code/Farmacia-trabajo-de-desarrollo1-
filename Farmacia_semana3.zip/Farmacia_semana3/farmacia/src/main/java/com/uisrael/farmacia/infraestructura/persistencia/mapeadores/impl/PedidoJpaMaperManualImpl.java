package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Pedido;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.PedidoEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IPedidoJpaMaper;

@Primary
@Component
public class PedidoJpaMaperManualImpl implements IPedidoJpaMaper {

	@Override
	public Pedido toDomain(PedidoEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Pedido(entity.getIdPedido(), entity.getIdCliente(), entity.getIdFarmacia(), entity.getFechaPedido(), entity.getEstadoPedido(), entity.getTotal());
	}

	@Override
	public PedidoEntity toEntity(Pedido pedidoPojo) {
		if (pedidoPojo == null) {
			return null;
		}
		PedidoEntity entity = new PedidoEntity();
		entity.setIdPedido(pedidoPojo.getIdPedido());
		entity.setIdCliente(pedidoPojo.getIdCliente());
		entity.setIdFarmacia(pedidoPojo.getIdFarmacia());
		entity.setFechaPedido(pedidoPojo.getFechaPedido());
		entity.setEstadoPedido(pedidoPojo.getEstadoPedido());
		entity.setTotal(pedidoPojo.getTotal());
		return entity;
	}
}
