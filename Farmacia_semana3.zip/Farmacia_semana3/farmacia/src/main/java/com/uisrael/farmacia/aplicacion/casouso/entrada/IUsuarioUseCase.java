package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;


import com.uisrael.farmacia.dominio.entidades.Usuario;

public interface IUsuarioUseCase {
	Usuario guardar(Usuario usuario);

Usuario busarPorId(int id);

	List<Usuario> listarTodos();

	void eliminar(int id);
}
