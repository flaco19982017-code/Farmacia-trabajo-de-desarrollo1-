package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Ruta;
import com.uisrael.farmacia.presentacion.dto.request.RutaRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.RutaResponseDto;

@Mapper(componentModel = "spring")
public interface IRutaDtoMapper {
	Ruta toDomain(RutaRequestDto dto);

	RutaResponseDto toResponseDto(Ruta ruta);
}
