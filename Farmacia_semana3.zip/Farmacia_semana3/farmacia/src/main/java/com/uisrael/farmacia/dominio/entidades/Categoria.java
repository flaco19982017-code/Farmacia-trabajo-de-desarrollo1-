package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;

public class Categoria implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private  int idCategoria;
	private  String nombreCategoria;
	private  String descripcion;
	public Categoria(int idCategoria, String nombreCategoria, String descripcion) {
	
		this.idCategoria = idCategoria;
		this.nombreCategoria = nombreCategoria;
		this.descripcion = descripcion;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public int getIdCategoria() {
		return idCategoria;
	}
	public String getNombreCategoria() {
		return nombreCategoria;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}
	public void setNombreCategoria(String nombreCategoria) {
		this.nombreCategoria = nombreCategoria;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
}
