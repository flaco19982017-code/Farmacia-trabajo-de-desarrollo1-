package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Vehiculo;
import com.uisrael.farmacia.presentacion.dto.request.VehiculoRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.VehiculoResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IVehiculoDtoMapper;

@Primary
@Component
public class VehiculoDtoMapperManualImpl implements IVehiculoDtoMapper {

	@Override
	public Vehiculo toDomain(VehiculoRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Vehiculo(dto.getIdVehiculo(), dto.getPlaca(), dto.getCapacidad(), dto.getEstado());
	}

	@Override
	public VehiculoResponseDto toResponseDto(Vehiculo vehiculo) {
		if (vehiculo == null) {
			return null;
		}
		VehiculoResponseDto dto = new VehiculoResponseDto();
		dto.setIdVehiculo(vehiculo.getIdVehiculo());
		dto.setPlaca(vehiculo.getPlaca());
		dto.setCapacidad(vehiculo.getCapacidad());
		dto.setEstado(vehiculo.getEstado());
		return dto;
	}
}
