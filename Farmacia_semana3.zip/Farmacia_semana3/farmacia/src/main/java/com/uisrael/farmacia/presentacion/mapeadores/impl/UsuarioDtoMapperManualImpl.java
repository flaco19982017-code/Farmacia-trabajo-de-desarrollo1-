package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Usuario;
import com.uisrael.farmacia.presentacion.dto.request.UsuarioRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.UsuarioResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IUsuarioDtoMapper;

@Primary
@Component
public class UsuarioDtoMapperManualImpl implements IUsuarioDtoMapper {

	@Override
	public Usuario toDomain(UsuarioRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Usuario(dto.getIdUsuario(), dto.getIdRol(), dto.getNombre(), dto.getCorreo(), dto.getClave(), dto.isEstado());
	}

	@Override
	public UsuarioResponseDto toResponseDto(Usuario usuario) {
		if (usuario == null) {
			return null;
		}
		UsuarioResponseDto dto = new UsuarioResponseDto();
		dto.setIdUsuario(usuario.getIdUsuario());
		dto.setIdRol(usuario.getIdRol());
		dto.setNombre(usuario.getNombre());
		dto.setCorreo(usuario.getCorreo());
		dto.setClave(usuario.getClave());
		dto.setEstado(usuario.isEstado());
		return dto;
	}
}
