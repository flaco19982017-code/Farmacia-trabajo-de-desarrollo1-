package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Producto;
import com.uisrael.farmacia.presentacion.dto.request.ProductoRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.ProductoResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IProductoDtoMapper;

@Primary
@Component
public class ProductoDtoMapperManualImpl implements IProductoDtoMapper {

	@Override
	public Producto toDomain(ProductoRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Producto(dto.getIdProducto(), dto.getIdCategoria(), dto.getIdLaboratorio(), dto.getNombreProducto(), dto.getDescripcion(), dto.getPrecio(), dto.getFechaCaducidad(), dto.isEstado());
	}

	@Override
	public ProductoResponseDto toResponseDto(Producto producto) {
		if (producto == null) {
			return null;
		}
		ProductoResponseDto dto = new ProductoResponseDto();
		dto.setIdProducto(producto.getIdProducto());
		dto.setIdCategoria(producto.getIdCategoria());
		dto.setIdLaboratorio(producto.getIdLaboratorio());
		dto.setNombreProducto(producto.getNombreProducto());
		dto.setDescripcion(producto.getDescripcion());
		dto.setPrecio(producto.getPrecio());
		dto.setFechaCaducidad(producto.getFechaCaducidad());
		dto.setEstado(producto.isEstado());
		return dto;
	}
}
