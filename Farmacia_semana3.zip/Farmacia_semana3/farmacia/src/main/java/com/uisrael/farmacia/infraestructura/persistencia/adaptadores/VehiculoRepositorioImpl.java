package com.uisrael.farmacia.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Vehiculo;
import com.uisrael.farmacia.dominio.repositorios.IVehiculoRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.VehiculoEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IVehiculoJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.IVehiculoJpaRepositorio;

public class VehiculoRepositorioImpl implements IVehiculoRepositorio {

	private final IVehiculoJpaRepositorio jpaRepositorio;
	private final IVehiculoJpaMaper entityMapper;

	public VehiculoRepositorioImpl(IVehiculoJpaRepositorio jpaRepositorio, IVehiculoJpaMaper entityMapper) {
		super();
		this.jpaRepositorio = jpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Vehiculo guardar(Vehiculo vehiculo) {
		VehiculoEntity entity = entityMapper.toEntity(vehiculo);
		VehiculoEntity guardardo = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardardo);
	}

	@Override
	public Optional<Vehiculo> busarPorId(int id) {
		return jpaRepositorio.findById(id).map(entityMapper::toDomain);
	}

	@Override
	public List<Vehiculo> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int id) {
		jpaRepositorio.deleteById(id);
	}
}