package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Categoria;


public interface ICategoriaRepositorio {
	Categoria guardar(Categoria categoria);
	Optional<Categoria>busarPorId(int id); 
	List<Categoria> listarTodos(); 
	void eliminar(int id);
}
