package com.uisrael.farmacia.presentacion.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ClienteRequestDto {

	private  int idCliente;
	@NotBlank
	private  String nombres;
	@NotBlank
	private  String identificacion;
	@NotBlank
	private  String telefono;
	@NotBlank
	private  String correo;
	@NotBlank
	private  String direccion;
	@NotBlank
	private  String tipoCliente;
	@NotBlank
	private  String clasificacion;
}
