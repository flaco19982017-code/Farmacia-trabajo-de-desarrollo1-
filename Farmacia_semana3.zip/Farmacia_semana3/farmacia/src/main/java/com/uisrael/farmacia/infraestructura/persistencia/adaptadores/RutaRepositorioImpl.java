package com.uisrael.farmacia.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Ruta;
import com.uisrael.farmacia.dominio.repositorios.IRutaRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.RutaEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IRutaJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.IRutaJpaRepositorio;

public class RutaRepositorioImpl implements IRutaRepositorio {

	private final IRutaJpaRepositorio jpaRepositorio;
	private final IRutaJpaMaper entityMapper;

	public RutaRepositorioImpl(IRutaJpaRepositorio jpaRepositorio, IRutaJpaMaper entityMapper) {
		super();
		this.jpaRepositorio = jpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Ruta guardar(Ruta ruta) {
		RutaEntity entity = entityMapper.toEntity(ruta);
		RutaEntity guardardo = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardardo);
	}

	@Override
	public Optional<Ruta> busarPorId(int id) {
		return jpaRepositorio.findById(id).map(entityMapper::toDomain);
	}

	@Override
	public List<Ruta> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int id) {
		jpaRepositorio.deleteById(id);
	}
}