package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Usuario;

public interface IUsuarioRepositorio {
	Usuario guardar(Usuario usuario);

	Optional<Usuario> busarPorId(int id);

	List<Usuario> listarTodos();

	void eliminar(int id);
}
