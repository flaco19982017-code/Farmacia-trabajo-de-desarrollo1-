package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;

public class Inventario implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private  int idInventario;

	private  int idFarmacia;
	private  int idProducto;
	private  int stockActual;
	private  int stockMinimo;
	public Inventario(int idInventario, int idFarmacia, int idProducto, int stockActual, int stockMinimo) {
	
		this.idInventario = idInventario;
		this.idFarmacia = idFarmacia;
		this.idProducto = idProducto;
		this.stockActual = stockActual;
		this.stockMinimo = stockMinimo;
	}
	public int getIdInventario() {
		return idInventario;
	}
	public int getIdFarmacia() {
		return idFarmacia;
	}
	public int getIdProducto() {
		return idProducto;
	}
	public int getStockActual() {
		return stockActual;
	}
	public int getStockMinimo() {
		return stockMinimo;
	}
	public void setIdInventario(int idInventario) {
		this.idInventario = idInventario;
	}
	public void setIdFarmacia(int idFarmacia) {
		this.idFarmacia = idFarmacia;
	}
	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}
	public void setStockActual(int stockActual) {
		this.stockActual = stockActual;
	}
	public void setStockMinimo(int stockMinimo) {
		this.stockMinimo = stockMinimo;
	}
	
}
