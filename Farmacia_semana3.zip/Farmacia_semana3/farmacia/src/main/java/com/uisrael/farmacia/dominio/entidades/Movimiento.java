package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Movimiento implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private  int idMovimiento;

	private  int idInventario;
	private  int idUsuario;
	private  String tipoMovimiento;
	private  int cantidad;
	private  LocalDateTime fechaMovimiento;
	private  String observacion;
	public Movimiento(int idMovimiento, int idInventario, int idUsuario, String tipoMovimiento, int cantidad,
			LocalDateTime fechaMovimiento, String observacion) {
	
		this.idMovimiento = idMovimiento;
		this.idInventario = idInventario;
		this.idUsuario = idUsuario;
		this.tipoMovimiento = tipoMovimiento;
		this.cantidad = cantidad;
		this.fechaMovimiento = fechaMovimiento;
		this.observacion = observacion;
	}
	public int getIdMovimiento() {
		return idMovimiento;
	}
	public int getIdInventario() {
		return idInventario;
	}
	public int getIdUsuario() {
		return idUsuario;
	}
	public String getTipoMovimiento() {
		return tipoMovimiento;
	}
	public int getCantidad() {
		return cantidad;
	}
	public LocalDateTime getFechaMovimiento() {
		return fechaMovimiento;
	}
	public String getObservacion() {
		return observacion;
	}
	public void setIdMovimiento(int idMovimiento) {
		this.idMovimiento = idMovimiento;
	}
	public void setIdInventario(int idInventario) {
		this.idInventario = idInventario;
	}
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	public void setTipoMovimiento(String tipoMovimiento) {
		this.tipoMovimiento = tipoMovimiento;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	public void setFechaMovimiento(LocalDateTime fechaMovimiento) {
		this.fechaMovimiento = fechaMovimiento;
	}
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	
}
