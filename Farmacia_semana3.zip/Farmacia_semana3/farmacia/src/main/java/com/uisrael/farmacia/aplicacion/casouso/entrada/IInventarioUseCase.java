package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;

import com.uisrael.farmacia.dominio.entidades.Inventario;

public interface IInventarioUseCase {
	Inventario guardar(Inventario inventario);
	Inventario busarPorId(int id);
	List<Inventario> listarTodos();
	void eliminar(int id);
}
