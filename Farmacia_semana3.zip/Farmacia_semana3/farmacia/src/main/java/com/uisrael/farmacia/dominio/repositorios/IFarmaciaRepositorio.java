package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Farmacia;

public interface IFarmaciaRepositorio {
	Farmacia guardar(Farmacia farmacia);

	Optional<Farmacia> busarPorId(int id);

	List<Farmacia> listarTodos();

	void eliminar(int id);
	
}
