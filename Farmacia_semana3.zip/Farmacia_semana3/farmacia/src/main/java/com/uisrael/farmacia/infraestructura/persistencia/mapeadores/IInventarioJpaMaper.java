package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Inventario;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.InventarioEntity;
@Mapper(componentModel = "spring")
public interface IInventarioJpaMaper {
	Inventario toDomain(InventarioEntity entity);
	InventarioEntity toEntity(Inventario inventarioPojo);
}
