package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Laboratorio;
import com.uisrael.farmacia.presentacion.dto.request.LaboratorioRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.LaboratorioResponseDto;

@Mapper(componentModel = "spring")
public interface ILaboratorioDtoMapper {
	Laboratorio toDomain(LaboratorioRequestDto dto);

	LaboratorioResponseDto toResponseDto(Laboratorio laboratorio);
}
