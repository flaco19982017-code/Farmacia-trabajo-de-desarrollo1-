package com.uisrael.farmacia.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IMovimientoUseCase;
import com.uisrael.farmacia.presentacion.dto.request.MovimientoRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.MovimientoResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IMovimientoDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/movimiento")
public class MovimientoController {
	private final IMovimientoUseCase movimientoUseCase;
    private final IMovimientoDtoMapper mapper;

    public MovimientoController(IMovimientoUseCase movimientoUseCase, IMovimientoDtoMapper mapper) {
        this.movimientoUseCase = movimientoUseCase;
        this.mapper = mapper;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public MovimientoResponseDto guardar(@Valid @RequestBody MovimientoRequestDto movimientoRequestDto) {
        return mapper.toResponseDto(
                movimientoUseCase.guardar(
                        mapper.toDomain(movimientoRequestDto)
                )
        );
    }

    @GetMapping
    public List<MovimientoResponseDto> listarTodo() {
        return movimientoUseCase.listarTodos()
                .stream()
                .map(mapper::toResponseDto)
                .toList();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable int id) {
        movimientoUseCase.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
