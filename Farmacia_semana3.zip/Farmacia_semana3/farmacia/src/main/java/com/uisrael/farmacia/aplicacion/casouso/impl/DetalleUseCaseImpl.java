package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IDetalleUseCase;
import com.uisrael.farmacia.dominio.entidades.Detalle;
import com.uisrael.farmacia.dominio.repositorios.IDetalleRepositorio;

public class DetalleUseCaseImpl implements IDetalleUseCase {
	private final IDetalleRepositorio repositorio;

	public DetalleUseCaseImpl(IDetalleRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Detalle guardar(Detalle detalle) {
		return repositorio.guardar(detalle);
	}

	@Override
	public Detalle busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("detalle no encontrado"));
	}

	@Override
	public List<Detalle> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
	}
}