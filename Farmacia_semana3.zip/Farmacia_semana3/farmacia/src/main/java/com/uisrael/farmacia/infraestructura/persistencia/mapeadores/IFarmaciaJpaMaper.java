package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Farmacia;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.FarmaciaEntity;
@Mapper(componentModel = "spring")
public interface IFarmaciaJpaMaper {
	Farmacia toDomain(FarmaciaEntity entity);
	FarmaciaEntity toEntity(Farmacia farmaciaPojo);
}
