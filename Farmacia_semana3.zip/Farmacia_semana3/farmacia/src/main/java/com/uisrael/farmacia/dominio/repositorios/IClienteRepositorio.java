package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Cliente;

public interface IClienteRepositorio {
	Cliente guardar(Cliente cliente);

	Optional<Cliente> busarPorId(int id);

	List<Cliente> listarTodos();

	void eliminar(int id);
}
