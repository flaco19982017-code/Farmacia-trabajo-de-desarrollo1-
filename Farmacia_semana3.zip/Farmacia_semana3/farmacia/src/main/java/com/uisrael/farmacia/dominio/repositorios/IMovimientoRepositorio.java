package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Movimiento;

public interface IMovimientoRepositorio {
	Movimiento guardar(Movimiento mantenimiento);

	Optional<Movimiento> busarPorId(int id);

	List<Movimiento> listarTodos();

	void eliminar(int id);
}
