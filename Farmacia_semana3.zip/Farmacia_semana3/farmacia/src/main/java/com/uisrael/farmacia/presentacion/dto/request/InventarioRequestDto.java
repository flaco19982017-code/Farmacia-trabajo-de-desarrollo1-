package com.uisrael.farmacia.presentacion.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class InventarioRequestDto {
	
	private int idInventario;
@NotBlank
	private  int idFarmacia;
@NotBlank
	private  int idProducto;
@NotBlank
	private  int stockActual;
@NotBlank
	private  int stockMinimo;
}
