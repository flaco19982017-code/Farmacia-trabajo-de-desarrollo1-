package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Usuario;
import com.uisrael.farmacia.presentacion.dto.request.UsuarioRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.UsuarioResponseDto;

@Mapper(componentModel = "spring")
public interface IUsuarioDtoMapper {
	Usuario toDomain(UsuarioRequestDto dto);

	UsuarioResponseDto toResponseDto(Usuario usuario);
}
