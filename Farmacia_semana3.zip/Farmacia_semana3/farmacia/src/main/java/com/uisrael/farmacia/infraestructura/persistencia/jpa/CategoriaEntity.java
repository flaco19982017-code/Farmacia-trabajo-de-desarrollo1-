package com.uisrael.farmacia.infraestructura.persistencia.jpa;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "categoria")
public class CategoriaEntity  {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  int idCategoria;

	private  String nombreCategoria;
	private  String descripcion;

}
