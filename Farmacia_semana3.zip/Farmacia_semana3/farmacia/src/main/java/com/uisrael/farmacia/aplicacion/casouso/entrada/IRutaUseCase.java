package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;


import com.uisrael.farmacia.dominio.entidades.Ruta;

public interface IRutaUseCase {
	Ruta guardar(Ruta ruta);

	Ruta busarPorId(int id);

	List<Ruta> listarTodos();

	void eliminar(int id);
}
