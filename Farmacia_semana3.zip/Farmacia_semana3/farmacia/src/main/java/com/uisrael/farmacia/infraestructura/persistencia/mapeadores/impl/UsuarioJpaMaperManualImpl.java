package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Usuario;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.UsuarioEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IUsuarioJpaMaper;

@Primary
@Component
public class UsuarioJpaMaperManualImpl implements IUsuarioJpaMaper {

	@Override
	public Usuario toDomain(UsuarioEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Usuario(entity.getIdUsuario(), entity.getIdRol(), entity.getNombre(), entity.getCorreo(), entity.getClave(), entity.isEstado());
	}

	@Override
	public UsuarioEntity toEntity(Usuario usuarioPojo) {
		if (usuarioPojo == null) {
			return null;
		}
		UsuarioEntity entity = new UsuarioEntity();
		entity.setIdUsuario(usuarioPojo.getIdUsuario());
		entity.setIdRol(usuarioPojo.getIdRol());
		entity.setNombre(usuarioPojo.getNombre());
		entity.setCorreo(usuarioPojo.getCorreo());
		entity.setClave(usuarioPojo.getClave());
		entity.setEstado(usuarioPojo.isEstado());
		return entity;
	}
}
