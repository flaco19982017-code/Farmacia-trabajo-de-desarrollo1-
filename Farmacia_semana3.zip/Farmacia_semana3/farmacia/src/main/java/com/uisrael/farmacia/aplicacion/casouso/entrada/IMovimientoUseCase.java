package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;

import com.uisrael.farmacia.dominio.entidades.Movimiento;

public interface IMovimientoUseCase {
	Movimiento guardar(Movimiento movimiento);
	Movimiento busarPorId(int id);
	List<Movimiento> listarTodos();
	void eliminar(int id);
}
