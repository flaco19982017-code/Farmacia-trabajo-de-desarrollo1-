package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;


import com.uisrael.farmacia.dominio.entidades.Cliente;

public interface IClienteUseCase {
	Cliente guardar(Cliente cliente);

	Cliente busarPorId(int id);

	List<Cliente> listarTodos();

	void eliminar(int id);
}
