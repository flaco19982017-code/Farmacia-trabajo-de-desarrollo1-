package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Vehiculo;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.VehiculoEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IVehiculoJpaMaper;

@Primary
@Component
public class VehiculoJpaMaperManualImpl implements IVehiculoJpaMaper {

	@Override
	public Vehiculo toDomain(VehiculoEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Vehiculo(entity.getIdVehiculo(), entity.getPlaca(), entity.getCapacidad(), entity.getEstado());
	}

	@Override
	public VehiculoEntity toEntity(Vehiculo vehiculoPojo) {
		if (vehiculoPojo == null) {
			return null;
		}
		VehiculoEntity entity = new VehiculoEntity();
		entity.setIdVehiculo(vehiculoPojo.getIdVehiculo());
		entity.setPlaca(vehiculoPojo.getPlaca());
		entity.setCapacidad(vehiculoPojo.getCapacidad());
		entity.setEstado(vehiculoPojo.getEstado());
		return entity;
	}
}
