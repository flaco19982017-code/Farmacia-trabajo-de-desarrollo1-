package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;


import com.uisrael.farmacia.dominio.entidades.Rol;

public interface IRolUseCase {
	  Rol guardar(Rol rol);

	    Rol busarPorId(int id);

	    List<Rol> listarTodos();

	    void eliminar(int id);
	}
