package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Laboratorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.LaboratorioEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.ILaboratorioJpaMaper;

@Primary
@Component
public class LaboratorioJpaMaperManualImpl implements ILaboratorioJpaMaper {

	@Override
	public Laboratorio toDomain(LaboratorioEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Laboratorio(entity.getIdLaboratorio(), entity.getNombreLaboratorio(), entity.getRuc(), entity.getTelefono(), entity.getDireccion());
	}

	@Override
	public LaboratorioEntity toEntity(Laboratorio laboratorioPojo) {
		if (laboratorioPojo == null) {
			return null;
		}
		LaboratorioEntity entity = new LaboratorioEntity();
		entity.setIdLaboratorio(laboratorioPojo.getIdLaboratorio());
		entity.setNombreLaboratorio(laboratorioPojo.getNombreLaboratorio());
		entity.setRuc(laboratorioPojo.getRuc());
		entity.setTelefono(laboratorioPojo.getTelefono());
		entity.setDireccion(laboratorioPojo.getDireccion());
		return entity;
	}
}
