package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Detalle;

public interface IDetalleRepositorio {

	Detalle guardar(Detalle detalle);

	Optional<Detalle> busarPorId(int id);

	List<Detalle> listarTodos();

	void eliminar(int id);
}
