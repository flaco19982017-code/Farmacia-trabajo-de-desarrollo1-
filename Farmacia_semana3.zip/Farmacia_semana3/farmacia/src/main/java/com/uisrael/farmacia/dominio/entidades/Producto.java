package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

public class Producto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private  int idProducto;

	private  int idCategoria;
	private  int idLaboratorio;
	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}
	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}
	public void setIdLaboratorio(int idLaboratorio) {
		this.idLaboratorio = idLaboratorio;
	}
	public void setNombreProducto(String nombreProducto) {
		this.nombreProducto = nombreProducto;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public void setPrecio(BigDecimal precio) {
		this.precio = precio;
	}
	public void setFechaCaducidad(LocalDate fechaCaducidad) {
		this.fechaCaducidad = fechaCaducidad;
	}
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	private  String nombreProducto;
	private  String descripcion;
	private  BigDecimal precio;
	private  LocalDate fechaCaducidad;
	private  boolean estado;
	public Producto(int idProducto, int idCategoria, int idLaboratorio, String nombreProducto, String descripcion,
			BigDecimal precio, LocalDate fechaCaducidad, boolean estado) {
	
		this.idProducto = idProducto;
		this.idCategoria = idCategoria;
		this.idLaboratorio = idLaboratorio;
		this.nombreProducto = nombreProducto;
		this.descripcion = descripcion;
		this.precio = precio;
		this.fechaCaducidad = fechaCaducidad;
		this.estado = estado;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public int getIdProducto() {
		return idProducto;
	}
	public int getIdCategoria() {
		return idCategoria;
	}
	public int getIdLaboratorio() {
		return idLaboratorio;
	}
	public String getNombreProducto() {
		return nombreProducto;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public BigDecimal getPrecio() {
		return precio;
	}
	public LocalDate getFechaCaducidad() {
		return fechaCaducidad;
	}
	public boolean isEstado() {
		return estado;
	}
	
}
