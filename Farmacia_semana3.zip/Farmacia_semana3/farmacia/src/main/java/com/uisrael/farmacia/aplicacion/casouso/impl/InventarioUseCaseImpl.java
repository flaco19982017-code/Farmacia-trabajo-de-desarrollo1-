package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IInventarioUseCase;
import com.uisrael.farmacia.dominio.entidades.Inventario;
import com.uisrael.farmacia.dominio.repositorios.IInventarioRepositorio;

public class InventarioUseCaseImpl implements IInventarioUseCase {
	private final IInventarioRepositorio repositorio;

	public InventarioUseCaseImpl(IInventarioRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Inventario guardar(Inventario inventario) {
		return repositorio.guardar(inventario);
	}

	@Override
	public Inventario busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("inventario no encontrado"));
	}

	@Override
	public List<Inventario> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
	}
}