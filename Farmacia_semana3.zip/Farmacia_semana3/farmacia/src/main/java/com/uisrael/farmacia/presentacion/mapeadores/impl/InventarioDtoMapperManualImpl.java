package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Inventario;
import com.uisrael.farmacia.presentacion.dto.request.InventarioRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.InventarioResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IInventarioDtoMapper;

@Primary
@Component
public class InventarioDtoMapperManualImpl implements IInventarioDtoMapper {

	@Override
	public Inventario toDomain(InventarioRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Inventario(dto.getIdInventario(), dto.getIdFarmacia(), dto.getIdProducto(), dto.getStockActual(), dto.getStockMinimo());
	}

	@Override
	public InventarioResponseDto toResponseDto(Inventario inventario) {
		if (inventario == null) {
			return null;
		}
		InventarioResponseDto dto = new InventarioResponseDto();
		dto.setIdInventario(inventario.getIdInventario());
		dto.setIdFarmacia(inventario.getIdFarmacia());
		dto.setIdProducto(inventario.getIdProducto());
		dto.setStockActual(inventario.getStockActual());
		dto.setStockMinimo(inventario.getStockMinimo());
		return dto;
	}
}
