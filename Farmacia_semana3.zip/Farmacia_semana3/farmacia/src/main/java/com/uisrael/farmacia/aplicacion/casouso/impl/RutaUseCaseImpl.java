package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IRutaUseCase;
import com.uisrael.farmacia.dominio.entidades.Ruta;
import com.uisrael.farmacia.dominio.repositorios.IRutaRepositorio;

public class RutaUseCaseImpl implements IRutaUseCase {
	private final IRutaRepositorio repositorio;

	public RutaUseCaseImpl(IRutaRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Ruta guardar(Ruta ruta) {
		return repositorio.guardar(ruta);
	}

	@Override
	public Ruta busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("ruta no encontrada"));
	}

	@Override
	public List<Ruta> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
	}
}