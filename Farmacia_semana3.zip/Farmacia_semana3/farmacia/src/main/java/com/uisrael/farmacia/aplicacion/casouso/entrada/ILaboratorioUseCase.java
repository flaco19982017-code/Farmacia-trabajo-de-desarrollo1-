package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;


import com.uisrael.farmacia.dominio.entidades.Laboratorio;

public interface ILaboratorioUseCase {
	Laboratorio guardar(Laboratorio laboratorio);

Laboratorio busarPorId(int id);

	List<Laboratorio> listarTodos();

	void eliminar(int id);
}
