package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Pedido;
import com.uisrael.farmacia.presentacion.dto.request.PedidoRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.PedidoResponseDto;

@Mapper(componentModel = "spring")
public interface IPedidoDtoMapper {
	Pedido toDomain(PedidoRequestDto dto);

	PedidoResponseDto toResponseDto(Pedido pedido);
}
