package com.uisrael.farmacia.presentacion.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class RolRequestDto {
	private  int idRol;
@NotBlank
	private  String nombreRol;
@NotBlank
	private  String descripcion;
}
