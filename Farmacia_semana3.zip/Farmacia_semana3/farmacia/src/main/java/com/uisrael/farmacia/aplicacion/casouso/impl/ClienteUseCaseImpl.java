package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IClienteUseCase;
import com.uisrael.farmacia.dominio.entidades.Cliente;
import com.uisrael.farmacia.dominio.repositorios.IClienteRepositorio;

public class ClienteUseCaseImpl implements IClienteUseCase {
	private final IClienteRepositorio repositorio;

	public ClienteUseCaseImpl(IClienteRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Cliente guardar(Cliente cliente) {
		return repositorio.guardar(cliente);
	}

	@Override
	public Cliente busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("cliente no encontrado"));
	}

	@Override
	public List<Cliente> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
	}
}