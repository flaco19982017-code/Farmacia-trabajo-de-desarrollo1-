package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;


import com.uisrael.farmacia.dominio.entidades.Farmacia;

public interface IFarmaciaUseCase {
	Farmacia guardar(Farmacia farmacia);

	Farmacia busarPorId(int id);

	List<Farmacia> listarTodos();

	void eliminar(int id);
}
