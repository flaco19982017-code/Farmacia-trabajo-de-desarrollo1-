package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Ruta;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.RutaEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IRutaJpaMaper;

@Primary
@Component
public class RutaJpaMaperManualImpl implements IRutaJpaMaper {

	@Override
	public Ruta toDomain(RutaEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Ruta(entity.getIdRuta(), entity.getIdPedido(), entity.getIdVehiculo(), entity.getIdUsuario(), entity.getFechaAsignacion(), entity.getEstadoRuta(), entity.getObservacion());
	}

	@Override
	public RutaEntity toEntity(Ruta rutaPojo) {
		if (rutaPojo == null) {
			return null;
		}
		RutaEntity entity = new RutaEntity();
		entity.setIdRuta(rutaPojo.getIdRuta());
		entity.setIdPedido(rutaPojo.getIdPedido());
		entity.setIdVehiculo(rutaPojo.getIdVehiculo());
		entity.setIdUsuario(rutaPojo.getIdUsuario());
		entity.setFechaAsignacion(rutaPojo.getFechaAsignacion());
		entity.setEstadoRuta(rutaPojo.getEstadoRuta());
		entity.setObservacion(rutaPojo.getObservacion());
		return entity;
	}
}
