package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.ILaboratorioUseCase;
import com.uisrael.farmacia.dominio.entidades.Laboratorio;
import com.uisrael.farmacia.dominio.repositorios.ILaboratorioRepositorio;

public class LaboratorioUseCaseImpl implements ILaboratorioUseCase {
	private final ILaboratorioRepositorio repositorio;

	public LaboratorioUseCaseImpl(ILaboratorioRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Laboratorio guardar(Laboratorio laboratorio) {
		return repositorio.guardar(laboratorio);
	}

	@Override
	public Laboratorio busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("laboratorio no encontrado"));
	}

	@Override
	public List<Laboratorio> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
	}
}