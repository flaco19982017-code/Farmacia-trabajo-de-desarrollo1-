package com.uisrael.farmacia.presentacion.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class VehiculoRequestDto {
	private  int idVehiculo;
@NotBlank
	private  String placa;
@NotBlank
	private  int capacidad;
@NotBlank
	private  String estado;
}
