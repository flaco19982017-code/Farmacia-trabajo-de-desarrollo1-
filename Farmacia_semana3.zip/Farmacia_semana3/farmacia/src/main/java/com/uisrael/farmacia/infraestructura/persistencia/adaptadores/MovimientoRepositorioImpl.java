package com.uisrael.farmacia.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Movimiento;
import com.uisrael.farmacia.dominio.repositorios.IMovimientoRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.MovimientoEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IMovimientoJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.IMovimientoJpaRepositorio;

public class MovimientoRepositorioImpl implements IMovimientoRepositorio {

	private final IMovimientoJpaRepositorio jpaRepositorio;
	private final IMovimientoJpaMaper entityMapper;

	public MovimientoRepositorioImpl(IMovimientoJpaRepositorio jpaRepositorio, IMovimientoJpaMaper entityMapper) {
		super();
		this.jpaRepositorio = jpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Movimiento guardar(Movimiento movimientoInventario) {
		MovimientoEntity entity = entityMapper.toEntity(movimientoInventario);
		MovimientoEntity guardardo = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardardo);
	}

	@Override
	public Optional<Movimiento> busarPorId(int id) {
		return jpaRepositorio.findById(id).map(entityMapper::toDomain);
	}

	@Override
	public List<Movimiento> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int id) {
		jpaRepositorio.deleteById(id);
	}
}