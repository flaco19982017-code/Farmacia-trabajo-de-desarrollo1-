package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Rol;
import com.uisrael.farmacia.presentacion.dto.request.RolRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.RolResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IRolDtoMapper;

@Primary
@Component
public class RolDtoMapperManualImpl implements IRolDtoMapper {

	@Override
	public Rol toDomain(RolRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Rol(dto.getIdRol(), dto.getNombreRol(), dto.getDescripcion());
	}

	@Override
	public RolResponseDto toResponseDto(Rol rol) {
		if (rol == null) {
			return null;
		}
		RolResponseDto dto = new RolResponseDto();
		dto.setIdRol(rol.getIdRol());
		dto.setNombreRol(rol.getNombreRol());
		dto.setDescripcion(rol.getDescripcion());
		return dto;
	}
}
