package com.uisrael.farmacia.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IUsuarioUseCase;
import com.uisrael.farmacia.presentacion.dto.request.UsuarioRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.UsuarioResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IUsuarioDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/usuario")
public class UsuarioController {
	private final IUsuarioUseCase usuarioUseCase;
    private final IUsuarioDtoMapper mapper;

    public UsuarioController(IUsuarioUseCase usuarioUseCase, IUsuarioDtoMapper mapper) {
        this.usuarioUseCase = usuarioUseCase;
        this.mapper = mapper;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public UsuarioResponseDto guardar(@Valid @RequestBody UsuarioRequestDto usuarioRequestDto) {
        return mapper.toResponseDto(
                usuarioUseCase.guardar(
                        mapper.toDomain(usuarioRequestDto)
                )
        );
    }

    @GetMapping
    public List<UsuarioResponseDto> listarTodo() {
        return usuarioUseCase.listarTodos()
                .stream()
                .map(mapper::toResponseDto)
                .toList();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable int id) {
        usuarioUseCase.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
