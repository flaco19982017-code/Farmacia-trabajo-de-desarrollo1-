package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Vehiculo;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.VehiculoEntity;
@Mapper(componentModel = "spring")
public interface IVehiculoJpaMaper {
	Vehiculo toDomain(VehiculoEntity entity);
	VehiculoEntity toEntity(Vehiculo vehiculoPojo);
}
