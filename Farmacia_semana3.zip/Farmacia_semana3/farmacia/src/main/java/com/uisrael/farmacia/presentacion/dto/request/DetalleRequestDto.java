package com.uisrael.farmacia.presentacion.dto.request;

import java.math.BigDecimal;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class DetalleRequestDto {
	private  int idDetalle;
	@NotBlank
	private  int idPedido;
	@NotBlank
	private  int idProducto;
	@NotBlank
	private  int cantidad;
	@NotBlank
	private  BigDecimal precioUnitario;
	@NotBlank
	private  BigDecimal subtotal;
}
