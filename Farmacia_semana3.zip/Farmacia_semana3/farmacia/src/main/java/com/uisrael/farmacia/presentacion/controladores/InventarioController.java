package com.uisrael.farmacia.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IInventarioUseCase;
import com.uisrael.farmacia.presentacion.dto.request.InventarioRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.InventarioResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IInventarioDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/inventario")
public class InventarioController {

    private final IInventarioUseCase inventarioUseCase;
    private final IInventarioDtoMapper mapper;

    public InventarioController(IInventarioUseCase inventarioUseCase, IInventarioDtoMapper mapper) {
        this.inventarioUseCase = inventarioUseCase;
        this.mapper = mapper;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public InventarioResponseDto guardar(@Valid @RequestBody InventarioRequestDto inventarioRequestDto) {
        return mapper.toResponseDto(
                inventarioUseCase.guardar(
                        mapper.toDomain(inventarioRequestDto)
                )
        );
    }

    @GetMapping
    public List<InventarioResponseDto> listarTodo() {
        return inventarioUseCase.listarTodos()
                .stream()
                .map(mapper::toResponseDto)
                .toList();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable int id) {
        inventarioUseCase.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
