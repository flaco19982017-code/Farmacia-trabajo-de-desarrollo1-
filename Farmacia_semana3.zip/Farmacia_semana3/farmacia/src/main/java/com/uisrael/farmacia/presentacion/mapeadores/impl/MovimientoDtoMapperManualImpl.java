package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Movimiento;
import com.uisrael.farmacia.presentacion.dto.request.MovimientoRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.MovimientoResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IMovimientoDtoMapper;

@Primary
@Component
public class MovimientoDtoMapperManualImpl implements IMovimientoDtoMapper {

	@Override
	public Movimiento toDomain(MovimientoRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Movimiento(dto.getIdMovimiento(), dto.getIdInventario(), dto.getIdUsuario(), dto.getTipoMovimiento(), dto.getCantidad(), dto.getFechaMovimiento(), dto.getObservacion());
	}

	@Override
	public MovimientoResponseDto toResponseDto(Movimiento movimiento) {
		if (movimiento == null) {
			return null;
		}
		MovimientoResponseDto dto = new MovimientoResponseDto();
		dto.setIdMovimiento(movimiento.getIdMovimiento());
		dto.setIdInventario(movimiento.getIdInventario());
		dto.setIdUsuario(movimiento.getIdUsuario());
		dto.setTipoMovimiento(movimiento.getTipoMovimiento());
		dto.setCantidad(movimiento.getCantidad());
		dto.setFechaMovimiento(movimiento.getFechaMovimiento());
		dto.setObservacion(movimiento.getObservacion());
		return dto;
	}
}
