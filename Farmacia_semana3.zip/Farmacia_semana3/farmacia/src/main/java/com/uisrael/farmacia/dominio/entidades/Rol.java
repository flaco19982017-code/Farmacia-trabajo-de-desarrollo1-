package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;

public class Rol implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private  int idRol;

	private  String nombreRol;
	private  String descripcion;
	public void setIdRol(int idRol) {
		this.idRol = idRol;
	}
	public void setNombreRol(String nombreRol) {
		this.nombreRol = nombreRol;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Rol(int idRol, String nombreRol, String descripcion) {
		
		this.idRol = idRol;
		this.nombreRol = nombreRol;
		this.descripcion = descripcion;
	}
	public int getIdRol() {
		return idRol;
	}
	public String getNombreRol() {
		return nombreRol;
	}
	public String getDescripcion() {
		return descripcion;
	}
	
}
