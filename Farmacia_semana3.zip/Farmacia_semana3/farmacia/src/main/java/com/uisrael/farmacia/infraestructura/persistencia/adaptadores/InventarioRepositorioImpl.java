package com.uisrael.farmacia.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Inventario;
import com.uisrael.farmacia.dominio.repositorios.IInventarioRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.InventarioEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IInventarioJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.IInventarioJpaRepositorio;

public class InventarioRepositorioImpl implements IInventarioRepositorio {

	private final IInventarioJpaRepositorio jpaRepositorio;
	private final IInventarioJpaMaper entityMapper;

	public InventarioRepositorioImpl(IInventarioJpaRepositorio jpaRepositorio, IInventarioJpaMaper entityMapper) {
		super();
		this.jpaRepositorio = jpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Inventario guardar(Inventario inventario) {
		InventarioEntity entity = entityMapper.toEntity(inventario);
		InventarioEntity guardardo = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardardo);
	}

	@Override
	public Optional<Inventario> busarPorId(int id) {
		return jpaRepositorio.findById(id).map(entityMapper::toDomain);
	}

	@Override
	public List<Inventario> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int id) {
		jpaRepositorio.deleteById(id);
	}
}