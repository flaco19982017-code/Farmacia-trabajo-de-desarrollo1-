package com.uisrael.farmacia.infraestructura.persistencia.jpa;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "ruta_distribucion")
public class RutaEntity  {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  int idRuta;

	private  int idPedido;
	private  int idVehiculo;
	private  int idUsuario;
	private  LocalDateTime fechaAsignacion;
	private  String estadoRuta;
	private  String observacion;
}
