package com.uisrael.farmacia.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IVehiculoUseCase;
import com.uisrael.farmacia.presentacion.dto.request.VehiculoRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.VehiculoResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IVehiculoDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/vehiculo")
public class VehiculoController {
	 private final IVehiculoUseCase vehiculoUseCase;
	    private final IVehiculoDtoMapper mapper;

	    public VehiculoController(IVehiculoUseCase vehiculoUseCase, IVehiculoDtoMapper mapper) {
	        this.vehiculoUseCase = vehiculoUseCase;
	        this.mapper = mapper;
	    }

	    @PostMapping
	    @ResponseStatus(HttpStatus.CREATED)
	    public VehiculoResponseDto guardar(@Valid @RequestBody VehiculoRequestDto vehiculoRequestDto) {
	        return mapper.toResponseDto(
	                vehiculoUseCase.guardar(
	                        mapper.toDomain(vehiculoRequestDto)
	                )
	        );
	    }

	    @GetMapping
	    public List<VehiculoResponseDto> listarTodo() {
	        return vehiculoUseCase.listarTodos()
	                .stream()
	                .map(mapper::toResponseDto)
	                .toList();
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> eliminar(@PathVariable int id) {
	        vehiculoUseCase.eliminar(id);
	        return ResponseEntity.noContent().build();
	    }
}
