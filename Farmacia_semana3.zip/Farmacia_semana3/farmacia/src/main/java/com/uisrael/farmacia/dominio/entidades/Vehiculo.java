package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;

public class Vehiculo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int idVehiculo;

	private  String placa;
	private  int capacidad;
	private  String estado;
	public Vehiculo(int idVehiculo, String placa, int capacidad, String estado) {
	
		this.idVehiculo = idVehiculo;
		this.placa = placa;
		this.capacidad = capacidad;
		this.estado = estado;
	}
	public int getIdVehiculo() {
		return idVehiculo;
	}
	public String getPlaca() {
		return placa;
	}
	public int getCapacidad() {
		return capacidad;
	}
	public String getEstado() {
		return estado;
	}
	public void setIdVehiculo(int idVehiculo) {
		this.idVehiculo = idVehiculo;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
}
