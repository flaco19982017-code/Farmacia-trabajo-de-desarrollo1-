package com.uisrael.farmacia.infraestructura.persistencia.jpa;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "producto")
public class ProductoEntity {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idProducto;

	private  int idCategoria;
	private  int idLaboratorio;
	private  String nombreProducto;
	private  String descripcion;
	private  BigDecimal precio;
	private  LocalDate fechaCaducidad;
	private  boolean estado;
}
