package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IMovimientoUseCase;
import com.uisrael.farmacia.dominio.entidades.Movimiento;
import com.uisrael.farmacia.dominio.repositorios.IMovimientoRepositorio;

public class MovimientoUseCaseImpl implements IMovimientoUseCase {
	private final IMovimientoRepositorio repositorio;

	public MovimientoUseCaseImpl(IMovimientoRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Movimiento guardar(Movimiento movimiento) {
		return repositorio.guardar(movimiento);
	}

	@Override
	public Movimiento busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("movimiento no encontrado"));
	}

	@Override
	public List<Movimiento> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
	}
}