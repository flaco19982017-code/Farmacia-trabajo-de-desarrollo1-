package com.uisrael.farmacia.infraestructura.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.uisrael.farmacia.infraestructura.persistencia.jpa.InventarioEntity;

public interface IInventarioJpaRepositorio extends  JpaRepository<InventarioEntity, Integer>{

}
