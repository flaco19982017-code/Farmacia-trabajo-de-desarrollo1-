package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IProductoUseCase;
import com.uisrael.farmacia.dominio.entidades.Producto;
import com.uisrael.farmacia.dominio.repositorios.IProductoRepositorio;

public class ProductoUseCaseImpl implements IProductoUseCase {
	private final IProductoRepositorio repositorio;

	public ProductoUseCaseImpl(IProductoRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Producto guardar(Producto producto) {
		return repositorio.guardar(producto);
	}

	@Override
	public Producto busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("producto no encontrado"));
	}

	@Override
	public List<Producto> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
	}
}