package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Cliente;
import com.uisrael.farmacia.presentacion.dto.request.ClienteRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.ClienteResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IClienteDtoMapper;

@Primary
@Component
public class ClienteDtoMapperManualImpl implements IClienteDtoMapper {

	@Override
	public Cliente toDomain(ClienteRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Cliente(dto.getIdCliente(), dto.getNombres(), dto.getIdentificacion(), dto.getTelefono(), dto.getCorreo(), dto.getDireccion(), dto.getTipoCliente(), dto.getClasificacion());
	}

	@Override
	public ClienteResponseDto toResponseDto(Cliente cliente) {
		if (cliente == null) {
			return null;
		}
		ClienteResponseDto dto = new ClienteResponseDto();
		dto.setIdCliente(cliente.getIdCliente());
		dto.setNombres(cliente.getNombres());
		dto.setIdentificacion(cliente.getIdentificacion());
		dto.setTelefono(cliente.getTelefono());
		dto.setCorreo(cliente.getCorreo());
		dto.setDireccion(cliente.getDireccion());
		dto.setTipoCliente(cliente.getTipoCliente());
		dto.setClasificacion(cliente.getClasificacion());
		return dto;
	}
}
