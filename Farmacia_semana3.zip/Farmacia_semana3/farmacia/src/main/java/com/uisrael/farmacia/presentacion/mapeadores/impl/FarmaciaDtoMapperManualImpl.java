package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Farmacia;
import com.uisrael.farmacia.presentacion.dto.request.FarmaciaRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.FarmaciaResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IFarmaciaDtoMapper;

@Primary
@Component
public class FarmaciaDtoMapperManualImpl implements IFarmaciaDtoMapper {

	@Override
	public Farmacia toDomain(FarmaciaRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Farmacia(dto.getIdFarmacia(), dto.getNombre(), dto.getDireccion(), dto.getZona(), dto.isEstado());
	}

	@Override
	public FarmaciaResponseDto toResponseDto(Farmacia farmacia) {
		if (farmacia == null) {
			return null;
		}
		FarmaciaResponseDto dto = new FarmaciaResponseDto();
		dto.setIdFarmacia(farmacia.getIdFarmacia());
		dto.setNombre(farmacia.getNombre());
		dto.setDireccion(farmacia.getDireccion());
		dto.setZona(farmacia.getZona());
		dto.setEstado(farmacia.isEstado());
		return dto;
	}
}
