package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Pedido implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private  int idPedido;

	private  int idCliente;
	private  int idFarmacia;
	private  LocalDateTime fechaPedido;
	private  String estadoPedido;
	private  BigDecimal total;
	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public void setIdFarmacia(int idFarmacia) {
		this.idFarmacia = idFarmacia;
	}
	public void setFechaPedido(LocalDateTime fechaPedido) {
		this.fechaPedido = fechaPedido;
	}
	public void setEstadoPedido(String estadoPedido) {
		this.estadoPedido = estadoPedido;
	}
	public void setTotal(BigDecimal total) {
		this.total = total;
	}
	public Pedido(int idPedido, int idCliente, int idFarmacia, LocalDateTime fechaPedido, String estadoPedido,
			BigDecimal total) {
		
		this.idPedido = idPedido;
		this.idCliente = idCliente;
		this.idFarmacia = idFarmacia;
		this.fechaPedido = fechaPedido;
		this.estadoPedido = estadoPedido;
		this.total = total;
	}
	public int getIdPedido() {
		return idPedido;
	}
	public int getIdCliente() {
		return idCliente;
	}
	public int getIdFarmacia() {
		return idFarmacia;
	}
	public LocalDateTime getFechaPedido() {
		return fechaPedido;
	}
	public String getEstadoPedido() {
		return estadoPedido;
	}
	public BigDecimal getTotal() {
		return total;
	}
	
}
