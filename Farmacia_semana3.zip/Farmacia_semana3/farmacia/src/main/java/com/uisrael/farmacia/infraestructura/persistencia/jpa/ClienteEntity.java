package com.uisrael.farmacia.infraestructura.persistencia.jpa;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "cliente")
public class ClienteEntity  {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  int idCliente;

	private  String nombres;
	private  String identificacion;
	private  String telefono;
	private  String correo;
	private  String direccion;
	private  String tipoCliente;
	private  String clasificacion;
}
