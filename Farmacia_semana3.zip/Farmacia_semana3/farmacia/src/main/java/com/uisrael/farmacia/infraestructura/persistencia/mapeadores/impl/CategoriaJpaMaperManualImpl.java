package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Categoria;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.CategoriaEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.ICategoriaJpaMaper;

@Primary
@Component
public class CategoriaJpaMaperManualImpl implements ICategoriaJpaMaper {

	@Override
	public Categoria toDomain(CategoriaEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Categoria(entity.getIdCategoria(), entity.getNombreCategoria(), entity.getDescripcion());
	}

	@Override
	public CategoriaEntity toEntity(Categoria categoriaPojo) {
		if (categoriaPojo == null) {
			return null;
		}
		CategoriaEntity entity = new CategoriaEntity();
		entity.setIdCategoria(categoriaPojo.getIdCategoria());
		entity.setNombreCategoria(categoriaPojo.getNombreCategoria());
		entity.setDescripcion(categoriaPojo.getDescripcion());
		return entity;
	}
}
