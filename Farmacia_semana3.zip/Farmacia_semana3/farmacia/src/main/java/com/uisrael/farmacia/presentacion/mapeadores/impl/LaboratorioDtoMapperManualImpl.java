package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Laboratorio;
import com.uisrael.farmacia.presentacion.dto.request.LaboratorioRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.LaboratorioResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.ILaboratorioDtoMapper;

@Primary
@Component
public class LaboratorioDtoMapperManualImpl implements ILaboratorioDtoMapper {

	@Override
	public Laboratorio toDomain(LaboratorioRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Laboratorio(dto.getIdLaboratorio(), dto.getNombreLaboratorio(), dto.getRuc(), dto.getTelefono(), dto.getDireccion());
	}

	@Override
	public LaboratorioResponseDto toResponseDto(Laboratorio laboratorio) {
		if (laboratorio == null) {
			return null;
		}
		LaboratorioResponseDto dto = new LaboratorioResponseDto();
		dto.setIdLaboratorio(laboratorio.getIdLaboratorio());
		dto.setNombreLaboratorio(laboratorio.getNombreLaboratorio());
		dto.setRuc(laboratorio.getRuc());
		dto.setTelefono(laboratorio.getTelefono());
		dto.setDireccion(laboratorio.getDireccion());
		return dto;
	}
}
