package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Categoria;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.CategoriaEntity;

@Mapper(componentModel = "spring")
public interface ICategoriaJpaMaper {
	 Categoria toDomain(CategoriaEntity entity);
		CategoriaEntity toEntity(Categoria categoriaPojo);
}
