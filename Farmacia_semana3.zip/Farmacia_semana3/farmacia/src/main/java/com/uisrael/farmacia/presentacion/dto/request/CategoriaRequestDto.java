package com.uisrael.farmacia.presentacion.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CategoriaRequestDto {
	private  int idCategoria;
@NotBlank
	private  String nombreCategoria;
@NotBlank
	private  String descripcion;
}
