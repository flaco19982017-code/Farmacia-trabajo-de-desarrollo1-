package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Rol;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.RolEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IRolJpaMaper;

@Primary
@Component
public class RolJpaMaperManualImpl implements IRolJpaMaper {

	@Override
	public Rol toDomain(RolEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Rol(entity.getIdRol(), entity.getNombreRol(), entity.getDescripcion());
	}

	@Override
	public RolEntity toEntity(Rol rolPojo) {
		if (rolPojo == null) {
			return null;
		}
		RolEntity entity = new RolEntity();
		entity.setIdRol(rolPojo.getIdRol());
		entity.setNombreRol(rolPojo.getNombreRol());
		entity.setDescripcion(rolPojo.getDescripcion());
		return entity;
	}
}
