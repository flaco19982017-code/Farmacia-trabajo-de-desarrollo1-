package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Producto;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.ProductoEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IProductoJpaMaper;

@Primary
@Component
public class ProductoJpaMaperManualImpl implements IProductoJpaMaper {

	@Override
	public Producto toDomain(ProductoEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Producto(entity.getIdProducto(), entity.getIdCategoria(), entity.getIdLaboratorio(), entity.getNombreProducto(), entity.getDescripcion(), entity.getPrecio(), entity.getFechaCaducidad(), entity.isEstado());
	}

	@Override
	public ProductoEntity toEntity(Producto productoPojo) {
		if (productoPojo == null) {
			return null;
		}
		ProductoEntity entity = new ProductoEntity();
		entity.setIdProducto(productoPojo.getIdProducto());
		entity.setIdCategoria(productoPojo.getIdCategoria());
		entity.setIdLaboratorio(productoPojo.getIdLaboratorio());
		entity.setNombreProducto(productoPojo.getNombreProducto());
		entity.setDescripcion(productoPojo.getDescripcion());
		entity.setPrecio(productoPojo.getPrecio());
		entity.setFechaCaducidad(productoPojo.getFechaCaducidad());
		entity.setEstado(productoPojo.isEstado());
		return entity;
	}
}
