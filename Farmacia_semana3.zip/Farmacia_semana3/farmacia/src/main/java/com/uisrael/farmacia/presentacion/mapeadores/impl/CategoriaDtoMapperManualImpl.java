package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Categoria;
import com.uisrael.farmacia.presentacion.dto.request.CategoriaRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.CategoriaResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.ICategoriaDtoMapper;

@Primary
@Component
public class CategoriaDtoMapperManualImpl implements ICategoriaDtoMapper {

	@Override
	public Categoria toDomain(CategoriaRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Categoria(dto.getIdCategoria(), dto.getNombreCategoria(), dto.getDescripcion());
	}

	@Override
	public CategoriaResponseDto toResponseDto(Categoria categoria) {
		if (categoria == null) {
			return null;
		}
		CategoriaResponseDto dto = new CategoriaResponseDto();
		dto.setIdCategoria(categoria.getIdCategoria());
		dto.setNombreCategoria(categoria.getNombreCategoria());
		dto.setDescripcion(categoria.getDescripcion());
		return dto;
	}
}
