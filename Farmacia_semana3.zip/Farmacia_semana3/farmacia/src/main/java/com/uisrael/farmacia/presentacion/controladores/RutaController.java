package com.uisrael.farmacia.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IRutaUseCase;
import com.uisrael.farmacia.presentacion.dto.request.RutaRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.RutaResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IRutaDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/ruta")
public class RutaController {
	 private final IRutaUseCase rutaUseCase;
	    private final IRutaDtoMapper mapper;

	    public RutaController(IRutaUseCase rutaUseCase, IRutaDtoMapper mapper) {
	        this.rutaUseCase = rutaUseCase;
	        this.mapper = mapper;
	    }

	    @PostMapping
	    @ResponseStatus(HttpStatus.CREATED)
	    public RutaResponseDto guardar(@Valid @RequestBody RutaRequestDto rutaRequestDto) {
	        return mapper.toResponseDto(
	                rutaUseCase.guardar(
	                        mapper.toDomain(rutaRequestDto)
	                )
	        );
	    }

	    @GetMapping
	    public List<RutaResponseDto> listarTodo() {
	        return rutaUseCase.listarTodos()
	                .stream()
	                .map(mapper::toResponseDto)
	                .toList();
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> eliminar(@PathVariable int id) {
	        rutaUseCase.eliminar(id);
	        return ResponseEntity.noContent().build();
	    }
}
