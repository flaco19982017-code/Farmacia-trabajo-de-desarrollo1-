package com.uisrael.farmacia.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.uisrael.farmacia.aplicacion.casouso.entrada.ILaboratorioUseCase;
import com.uisrael.farmacia.presentacion.dto.request.LaboratorioRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.LaboratorioResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.ILaboratorioDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/laboratorio")
public class LaboratorioController {

    private final ILaboratorioUseCase laboratorioUseCase;
    private final ILaboratorioDtoMapper mapper;

    public LaboratorioController(ILaboratorioUseCase laboratorioUseCase, ILaboratorioDtoMapper mapper) {
        this.laboratorioUseCase = laboratorioUseCase;
        this.mapper = mapper;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public LaboratorioResponseDto guardar(@Valid @RequestBody LaboratorioRequestDto laboratorioRequestDto) {
        return mapper.toResponseDto(
                laboratorioUseCase.guardar(
                        mapper.toDomain(laboratorioRequestDto)
                )
        );
    }

    @GetMapping
    public List<LaboratorioResponseDto> listarTodo() {
        return laboratorioUseCase.listarTodos()
                .stream()
                .map(mapper::toResponseDto)
                .toList();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable int id) {
        laboratorioUseCase.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
