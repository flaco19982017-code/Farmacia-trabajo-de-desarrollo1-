package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;


import com.uisrael.farmacia.dominio.entidades.Vehiculo;

public interface IVehiculoUseCase {
	Vehiculo guardar(Vehiculo vehiculo);

Vehiculo busarPorId(int id);

	List<Vehiculo> listarTodos();

	void eliminar(int id);
}
