package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Producto;

public interface IProductoRepositorio {
	Producto guardar(Producto producto);

	Optional<Producto> busarPorId(int id);

	List<Producto> listarTodos();

	void eliminar(int id);
}
