package com.uisrael.farmacia.presentacion.dto.response;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ProductoResponseDto {
	private  int idProducto;

	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}
	private  int idCategoria;
	private  int idLaboratorio;
	private  String nombreProducto;
	private  String descripcion;
	private  BigDecimal precio;
	private  LocalDate fechaCaducidad;
	private  boolean estado;
	public int getIdCategoria() {
		return idCategoria;
	}
	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}
	public int getIdLaboratorio() {
		return idLaboratorio;
	}
	public void setIdLaboratorio(int idLaboratorio) {
		this.idLaboratorio = idLaboratorio;
	}
	public String getNombreProducto() {
		return nombreProducto;
	}
	public void setNombreProducto(String nombreProducto) {
		this.nombreProducto = nombreProducto;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public BigDecimal getPrecio() {
		return precio;
	}
	public void setPrecio(BigDecimal precio) {
		this.precio = precio;
	}
	public LocalDate getFechaCaducidad() {
		return fechaCaducidad;
	}
	public void setFechaCaducidad(LocalDate fechaCaducidad) {
		this.fechaCaducidad = fechaCaducidad;
	}
	public boolean isEstado() {
		return estado;
	}
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	public int getIdProducto() {
		return idProducto;
	}
}
