package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Cliente;
import com.uisrael.farmacia.presentacion.dto.request.ClienteRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.ClienteResponseDto;

@Mapper(componentModel = "spring")
public interface IClienteDtoMapper {
	Cliente toDomain(ClienteRequestDto dto);

	ClienteResponseDto toResponseDto(Cliente cliente);
}
