package com.uisrael.farmacia.presentacion.dto.request;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class RutaRequestDto {
	private  int idRuta;
@NotBlank
	private  int idPedido;
@NotBlank
	private  int idVehiculo;
@NotBlank
	private  int idUsuario;
@NotBlank
	private  LocalDateTime fechaAsignacion;
@NotBlank
	private  String estadoRuta;
@NotBlank
	private  String observacion;
}
