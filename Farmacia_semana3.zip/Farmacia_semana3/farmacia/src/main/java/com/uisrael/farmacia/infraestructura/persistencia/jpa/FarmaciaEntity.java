package com.uisrael.farmacia.infraestructura.persistencia.jpa;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
@Data
@Entity
@Table(name = "farmacia")
public class FarmaciaEntity {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  int idFarmacia;

	private  String nombre;
	private  String direccion;
	private  String zona;
	private  boolean estado;
}
