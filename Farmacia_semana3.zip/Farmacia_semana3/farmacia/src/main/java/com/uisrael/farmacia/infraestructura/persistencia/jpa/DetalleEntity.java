package com.uisrael.farmacia.infraestructura.persistencia.jpa;

import java.math.BigDecimal;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "detalle_pedido")
public class DetalleEntity {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  int idDetalle;

	private  int idPedido;
	private  int idProducto;
	private  int cantidad;
	private  BigDecimal precioUnitario;
	private  BigDecimal subtotal;
}
