package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Ruta;

public interface IRutaRepositorio {
	Ruta guardar(Ruta ruta);

	Optional<Ruta> busarPorId(int id);

	List<Ruta> listarTodos();

	void eliminar(int id);
}
