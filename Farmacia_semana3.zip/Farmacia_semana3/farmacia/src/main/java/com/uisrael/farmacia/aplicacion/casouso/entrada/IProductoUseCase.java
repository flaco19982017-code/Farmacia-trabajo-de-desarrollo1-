package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;


import com.uisrael.farmacia.dominio.entidades.Producto;

public interface IProductoUseCase {
	Producto guardar(Producto producto);

	Producto busarPorId(int id);

	List<Producto> listarTodos();

	void eliminar(int id);
}
