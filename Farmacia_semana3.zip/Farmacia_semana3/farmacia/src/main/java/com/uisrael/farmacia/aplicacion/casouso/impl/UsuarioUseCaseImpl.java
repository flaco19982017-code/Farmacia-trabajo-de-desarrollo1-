package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;


import com.uisrael.farmacia.aplicacion.casouso.entrada.IUsuarioUseCase;
import com.uisrael.farmacia.dominio.entidades.Usuario;

import com.uisrael.farmacia.dominio.repositorios.IUsuarioRepositorio;

public class UsuarioUseCaseImpl implements IUsuarioUseCase {
	private final IUsuarioRepositorio repositorio;

	public UsuarioUseCaseImpl(IUsuarioRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Usuario guardar(Usuario usuario) {
		return repositorio.guardar(usuario);
	}

	@Override
	public Usuario busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("usuario no encontrada"));
	}

	@Override
	public List<Usuario> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
		
	}

}
