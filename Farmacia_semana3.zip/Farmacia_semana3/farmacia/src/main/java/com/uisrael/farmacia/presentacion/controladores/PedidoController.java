package com.uisrael.farmacia.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IPedidoUseCase;
import com.uisrael.farmacia.presentacion.dto.request.PedidoRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.PedidoResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IPedidoDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/pedido")
public class PedidoController {
	 private final IPedidoUseCase pedidoUseCase;
	    private final IPedidoDtoMapper mapper;

	    public PedidoController(IPedidoUseCase pedidoUseCase, IPedidoDtoMapper mapper) {
	        this.pedidoUseCase = pedidoUseCase;
	        this.mapper = mapper;
	    }

	    @PostMapping
	    @ResponseStatus(HttpStatus.CREATED)
	    public PedidoResponseDto guardar(@Valid @RequestBody PedidoRequestDto pedidoRequestDto) {
	        return mapper.toResponseDto(
	                pedidoUseCase.guardar(
	                        mapper.toDomain(pedidoRequestDto)
	                )
	        );
	    }

	    @GetMapping
	    public List<PedidoResponseDto> listarTodo() {
	        return pedidoUseCase.listarTodos()
	                .stream()
	                .map(mapper::toResponseDto)
	                .toList();
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> eliminar(@PathVariable int id) {
	        pedidoUseCase.eliminar(id);
	        return ResponseEntity.noContent().build();
	    }
}
