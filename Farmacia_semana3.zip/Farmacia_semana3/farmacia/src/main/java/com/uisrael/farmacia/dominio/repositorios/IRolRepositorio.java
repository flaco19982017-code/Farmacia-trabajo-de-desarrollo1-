package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Rol;

public interface IRolRepositorio {
	Rol guardar(Rol rol);

	Optional<Rol> busarPorId(int id);

	List<Rol> listarTodos();

	void eliminar(int id);
}
