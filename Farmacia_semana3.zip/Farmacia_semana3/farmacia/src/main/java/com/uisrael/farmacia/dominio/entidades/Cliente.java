package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;

public class Cliente implements Serializable {
	private static final long serialVersionUID = 1L;

	private int idCliente;
	private String nombres;
	private String identificacion;
	private String telefono;
	private String correo;
	private String direccion;
	private String tipoCliente;
	private String clasificacion;

	public Cliente(int idCliente, String nombres, String identificacion, String telefono, String correo,
			String direccion, String tipoCliente, String clasificacion) {
		this.idCliente = idCliente;
		this.nombres = nombres;
		this.identificacion = identificacion;
		this.telefono = telefono;
		this.correo = correo;
		this.direccion = direccion;
		this.tipoCliente = tipoCliente;
		this.clasificacion = clasificacion;
	}

	public int getIdCliente() { return idCliente; }
	public void setIdCliente(int idCliente) { this.idCliente = idCliente; }
	public String getNombres() { return nombres; }
	public void setNombres(String nombres) { this.nombres = nombres; }
	public String getIdentificacion() { return identificacion; }
	public void setIdentificacion(String identificacion) { this.identificacion = identificacion; }
	public String getTelefono() { return telefono; }
	public void setTelefono(String telefono) { this.telefono = telefono; }
	public String getCorreo() { return correo; }
	public void setCorreo(String correo) { this.correo = correo; }
	public String getDireccion() { return direccion; }
	public void setDireccion(String direccion) { this.direccion = direccion; }
	public String getTipoCliente() { return tipoCliente; }
	public void setTipoCliente(String tipoCliente) { this.tipoCliente = tipoCliente; }
	public String getClasificacion() { return clasificacion; }
	public void setClasificacion(String clasificacion) { this.clasificacion = clasificacion; }
}
