package com.uisrael.farmacia.presentacion.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UsuarioRequestDto {
	private  int idUsuario;
@NotBlank
	private  int idRol;
@NotBlank
	private  String nombre;
@NotBlank
	private  String correo;
@NotBlank
	private  String clave;
@NotBlank
	private  boolean estado;
}
