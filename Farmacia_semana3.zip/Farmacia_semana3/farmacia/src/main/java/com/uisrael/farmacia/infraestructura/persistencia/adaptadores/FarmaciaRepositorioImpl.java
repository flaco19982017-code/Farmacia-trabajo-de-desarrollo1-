package com.uisrael.farmacia.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Farmacia;
import com.uisrael.farmacia.dominio.repositorios.IFarmaciaRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.FarmaciaEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IFarmaciaJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.IFarmaciaJpaRepositorio;

public class FarmaciaRepositorioImpl implements IFarmaciaRepositorio {

	private final IFarmaciaJpaRepositorio jpaRepositorio;
	private final IFarmaciaJpaMaper entityMapper;

	public FarmaciaRepositorioImpl(IFarmaciaJpaRepositorio jpaRepositorio, IFarmaciaJpaMaper entityMapper) {
		super();
		this.jpaRepositorio = jpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Farmacia guardar(Farmacia farmacia) {
		FarmaciaEntity entity = entityMapper.toEntity(farmacia);
		FarmaciaEntity guardardo = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardardo);
	}

	@Override
	public Optional<Farmacia> busarPorId(int id) {
		return jpaRepositorio.findById(id).map(entityMapper::toDomain);
	}

	@Override
	public List<Farmacia> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int id) {
		jpaRepositorio.deleteById(id);
	}
}