package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IVehiculoUseCase;
import com.uisrael.farmacia.dominio.entidades.Vehiculo;
import com.uisrael.farmacia.dominio.repositorios.IVehiculoRepositorio;

public class VehiculoUseCaseImpl implements IVehiculoUseCase {
	private final IVehiculoRepositorio repositorio;

	public VehiculoUseCaseImpl(IVehiculoRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Vehiculo guardar(Vehiculo vehiculo) {
		return repositorio.guardar(vehiculo);
	}

	@Override
	public Vehiculo busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("vehiculo no encontrado"));
	}

	@Override
	public List<Vehiculo> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
	}
}