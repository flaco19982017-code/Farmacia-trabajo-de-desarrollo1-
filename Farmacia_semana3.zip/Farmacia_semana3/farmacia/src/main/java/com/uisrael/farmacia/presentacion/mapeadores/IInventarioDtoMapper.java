package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Inventario;
import com.uisrael.farmacia.presentacion.dto.request.InventarioRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.InventarioResponseDto;

@Mapper(componentModel = "spring")
public interface IInventarioDtoMapper {
	Inventario toDomain(InventarioRequestDto dto);

	InventarioResponseDto toResponseDto(Inventario inventario);
}
