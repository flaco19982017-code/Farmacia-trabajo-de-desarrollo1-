package com.uisrael.farmacia.presentacion.dto.request;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class ProductoRequestDto {
	private final int idProducto;
@NotBlank
	private  int idCategoria;
@NotBlank
	private  int idLaboratorio;
@NotBlank
	private  String nombreProducto;
@NotBlank
	private  String descripcion;
@NotBlank
	private  BigDecimal precio;
@NotBlank
	private  LocalDate fechaCaducidad;
@NotBlank
	private  boolean estado;
}
