package com.uisrael.farmacia.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IDetalleUseCase;
import com.uisrael.farmacia.presentacion.dto.request.DetalleRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.DetalleResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IDetalleDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/detalle")
public class DetalleController {
	private final IDetalleUseCase detalleUseCase;
    private final IDetalleDtoMapper mapper;

    public DetalleController(IDetalleUseCase detalleUseCase, IDetalleDtoMapper mapper) {
        this.detalleUseCase = detalleUseCase;
        this.mapper = mapper;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public DetalleResponseDto guardar(@Valid @RequestBody DetalleRequestDto detalleRequestDto) {
        return mapper.toResponseDto(
                detalleUseCase.guardar(
                        mapper.toDomain(detalleRequestDto)
                )
        );
    }

    @GetMapping
    public List<DetalleResponseDto> listarTodo() {
        return detalleUseCase.listarTodos()
                .stream()
                .map(mapper::toResponseDto)
                .toList();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable int id) {
        detalleUseCase.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
