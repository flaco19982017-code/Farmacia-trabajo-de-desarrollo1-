package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Vehiculo;

public interface IVehiculoRepositorio {
	Vehiculo guardar(Vehiculo vehiculo);

	Optional<Vehiculo> busarPorId(int id);

	List<Vehiculo> listarTodos();

	void eliminar(int id);
}
