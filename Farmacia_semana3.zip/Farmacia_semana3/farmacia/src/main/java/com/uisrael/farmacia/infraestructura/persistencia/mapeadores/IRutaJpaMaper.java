package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Ruta;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.RutaEntity;
@Mapper(componentModel = "spring")
public interface IRutaJpaMaper {
	Ruta toDomain(RutaEntity entity);
	RutaEntity toEntity(Ruta rutaPojo);
}
