package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IRolUseCase;
import com.uisrael.farmacia.dominio.entidades.Rol;
import com.uisrael.farmacia.dominio.repositorios.IRolRepositorio;

public class RolUseCaseImpl implements IRolUseCase{
	private final IRolRepositorio repositorio;

	public RolUseCaseImpl(IRolRepositorio repositorio) {
		this.repositorio = repositorio;}
	@Override
	public Rol guardar(Rol rol) {
		return repositorio.guardar(rol);
	}

	@Override
	public Rol busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("rol no encontrado"));
	}

	@Override
	public List<Rol> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
		
	}

}
