package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Movimiento;
import com.uisrael.farmacia.presentacion.dto.request.MovimientoRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.MovimientoResponseDto;

@Mapper(componentModel = "spring")
public interface IMovimientoDtoMapper {
	Movimiento toDomain(MovimientoRequestDto dto);

	MovimientoResponseDto toResponseDto(Movimiento movimiento);
}
