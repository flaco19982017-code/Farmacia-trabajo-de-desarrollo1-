package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Ruta implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private  int idRuta;

	private  int idPedido;
	private  int idVehiculo;
	private  int idUsuario;
	private  LocalDateTime fechaAsignacion;
	private  String estadoRuta;
	private  String observacion;
	public void setIdRuta(int idRuta) {
		this.idRuta = idRuta;
	}
	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}
	public void setIdVehiculo(int idVehiculo) {
		this.idVehiculo = idVehiculo;
	}
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	public void setFechaAsignacion(LocalDateTime fechaAsignacion) {
		this.fechaAsignacion = fechaAsignacion;
	}
	public void setEstadoRuta(String estadoRuta) {
		this.estadoRuta = estadoRuta;
	}
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	public Ruta(int idRuta, int idPedido, int idVehiculo, int idUsuario, LocalDateTime fechaAsignacion,
			String estadoRuta, String observacion) {
	
		this.idRuta = idRuta;
		this.idPedido = idPedido;
		this.idVehiculo = idVehiculo;
		this.idUsuario = idUsuario;
		this.fechaAsignacion = fechaAsignacion;
		this.estadoRuta = estadoRuta;
		this.observacion = observacion;
	}
	public int getIdRuta() {
		return idRuta;
	}
	public int getIdPedido() {
		return idPedido;
	}
	public int getIdVehiculo() {
		return idVehiculo;
	}
	public int getIdUsuario() {
		return idUsuario;
	}
	public LocalDateTime getFechaAsignacion() {
		return fechaAsignacion;
	}
	public String getEstadoRuta() {
		return estadoRuta;
	}
	public String getObservacion() {
		return observacion;
	}
	
}
