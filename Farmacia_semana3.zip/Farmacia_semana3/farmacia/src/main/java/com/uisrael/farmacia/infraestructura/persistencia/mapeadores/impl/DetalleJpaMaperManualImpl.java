package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Detalle;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.DetalleEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IDetalleJpaMaper;

@Primary
@Component
public class DetalleJpaMaperManualImpl implements IDetalleJpaMaper {

	@Override
	public Detalle toDomain(DetalleEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Detalle(entity.getIdDetalle(), entity.getIdPedido(), entity.getIdProducto(), entity.getCantidad(), entity.getPrecioUnitario(), entity.getSubtotal());
	}

	@Override
	public DetalleEntity toEntity(Detalle detallePojo) {
		if (detallePojo == null) {
			return null;
		}
		DetalleEntity entity = new DetalleEntity();
		entity.setIdDetalle(detallePojo.getIdDetalle());
		entity.setIdPedido(detallePojo.getIdPedido());
		entity.setIdProducto(detallePojo.getIdProducto());
		entity.setCantidad(detallePojo.getCantidad());
		entity.setPrecioUnitario(detallePojo.getPrecioUnitario());
		entity.setSubtotal(detallePojo.getSubtotal());
		return entity;
	}
}
