package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Pedido;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.PedidoEntity;
@Mapper(componentModel = "spring")
public interface IPedidoJpaMaper {
	Pedido toDomain(PedidoEntity entity);
	PedidoEntity toEntity(Pedido pedidoPojo);
}
