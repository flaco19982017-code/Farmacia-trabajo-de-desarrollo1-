package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Producto;
import com.uisrael.farmacia.presentacion.dto.request.ProductoRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.ProductoResponseDto;

@Mapper(componentModel = "spring")
public interface IProductoDtoMapper {
	Producto toDomain(ProductoRequestDto  dto);

	ProductoResponseDto toResponseDto(Producto producto);
}
