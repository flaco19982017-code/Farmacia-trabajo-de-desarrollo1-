package com.uisrael.farmacia.presentacion.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class FarmaciaRequestDto {
	private  int idFarmacia;
@NotBlank
	private  String nombre;
@NotBlank
	private  String direccion;
@NotBlank
	private  String zona;
@NotBlank
	private  boolean estado;
}
