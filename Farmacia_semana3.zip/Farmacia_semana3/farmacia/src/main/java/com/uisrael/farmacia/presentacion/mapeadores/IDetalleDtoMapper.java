package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Detalle;
import com.uisrael.farmacia.presentacion.dto.request.DetalleRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.DetalleResponseDto;

@Mapper(componentModel = "spring")
public interface IDetalleDtoMapper {
	Detalle toDomain(DetalleRequestDto dto);

	DetalleResponseDto toResponseDto(Detalle detalle);
}
