package com.uisrael.farmacia.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Laboratorio;
import com.uisrael.farmacia.dominio.repositorios.ILaboratorioRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.LaboratorioEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.ILaboratorioJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.ILaboratorioJpaRepositorio;

public class LaboratorioRepositorioImpl implements ILaboratorioRepositorio {

	private final ILaboratorioJpaRepositorio jpaRepositorio;
	private final ILaboratorioJpaMaper entityMapper;

	public LaboratorioRepositorioImpl(ILaboratorioJpaRepositorio jpaRepositorio, ILaboratorioJpaMaper entityMapper) {
		super();
		this.jpaRepositorio = jpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Laboratorio guardar(Laboratorio laboratorio) {
		LaboratorioEntity entity = entityMapper.toEntity(laboratorio);
		LaboratorioEntity guardardo = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardardo);
	}

	@Override
	public Optional<Laboratorio> busarPorId(int id) {
		return jpaRepositorio.findById(id).map(entityMapper::toDomain);
	}

	@Override
	public List<Laboratorio> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int id) {
		jpaRepositorio.deleteById(id);
	}
}