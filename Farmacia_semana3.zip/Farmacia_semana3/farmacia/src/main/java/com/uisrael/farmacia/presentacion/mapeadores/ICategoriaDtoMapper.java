package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Categoria;
import com.uisrael.farmacia.presentacion.dto.request.CategoriaRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.CategoriaResponseDto;

@Mapper(componentModel = "spring")
public interface ICategoriaDtoMapper {
	Categoria toDomain(CategoriaRequestDto dto);
	
	CategoriaResponseDto toResponseDto(Categoria categoria);
}
