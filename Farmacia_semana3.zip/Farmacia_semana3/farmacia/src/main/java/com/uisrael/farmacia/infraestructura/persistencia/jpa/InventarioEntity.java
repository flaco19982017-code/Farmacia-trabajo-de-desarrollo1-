package com.uisrael.farmacia.infraestructura.persistencia.jpa;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
@Data
@Entity
@Table(name = "inventario")
public class InventarioEntity {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idInventario;

	private  int idFarmacia;
	private  int idProducto;
	private  int stockActual;
	private  int stockMinimo;

}
