package com.uisrael.farmacia.infraestructura.persistencia.jpa;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "movimiento_inventario")
public class MovimientoEntity {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  int idMovimiento;

	private  int idInventario;
	private  int idUsuario;
	private  String tipoMovimiento;
	private  int cantidad;
	private  LocalDateTime fechaMovimiento;
	private  String observacion;
}
