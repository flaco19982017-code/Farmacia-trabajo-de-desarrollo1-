package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Cliente;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.ClienteEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IClienteJpaMaper;

@Primary
@Component
public class ClienteJpaMaperManualImpl implements IClienteJpaMaper {

	@Override
	public Cliente toDomain(ClienteEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Cliente(entity.getIdCliente(), entity.getNombres(), entity.getIdentificacion(), entity.getTelefono(), entity.getCorreo(), entity.getDireccion(), entity.getTipoCliente(), entity.getClasificacion());
	}

	@Override
	public ClienteEntity toEntity(Cliente clientePojo) {
		if (clientePojo == null) {
			return null;
		}
		ClienteEntity entity = new ClienteEntity();
		entity.setIdCliente(clientePojo.getIdCliente());
		entity.setNombres(clientePojo.getNombres());
		entity.setIdentificacion(clientePojo.getIdentificacion());
		entity.setTelefono(clientePojo.getTelefono());
		entity.setCorreo(clientePojo.getCorreo());
		entity.setDireccion(clientePojo.getDireccion());
		entity.setTipoCliente(clientePojo.getTipoCliente());
		entity.setClasificacion(clientePojo.getClasificacion());
		return entity;
	}
}
