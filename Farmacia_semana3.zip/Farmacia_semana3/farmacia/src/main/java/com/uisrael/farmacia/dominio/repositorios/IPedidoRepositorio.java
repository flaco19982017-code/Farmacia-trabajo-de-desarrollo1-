package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Pedido;

public interface IPedidoRepositorio {
	Pedido guardar(Pedido pedido);

	Optional<Pedido> busarPorId(int id);

	List<Pedido> listarTodos();

	void eliminar(int id);
}
