package com.uisrael.farmacia.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Usuario;
import com.uisrael.farmacia.dominio.repositorios.IUsuarioRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.UsuarioEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IUsuarioJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.IUsuarioJpaRepositorio;

public class UsuarioRepositorioImpl implements IUsuarioRepositorio {

	private final IUsuarioJpaRepositorio jpaRepositorio;
	private final IUsuarioJpaMaper entityMapper;

	public UsuarioRepositorioImpl(IUsuarioJpaRepositorio jpaRepositorio, IUsuarioJpaMaper entityMapper) {
		super();
		this.jpaRepositorio = jpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Usuario guardar(Usuario usuario) {
		UsuarioEntity entity = entityMapper.toEntity(usuario);
		UsuarioEntity guardardo = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardardo);
	}

	@Override
	public Optional<Usuario> busarPorId(int id) {
		return jpaRepositorio.findById(id).map(entityMapper::toDomain);
	}

	@Override
	public List<Usuario> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int id) {
		jpaRepositorio.deleteById(id);
	}
}