package com.uisrael.farmacia.infraestructura.persistencia.jpa;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "vehiculo")
public class VehiculoEntity  {
	;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  int idVehiculo;

	private  String placa;
	private  int capacidad;
	private  String estado;
}
