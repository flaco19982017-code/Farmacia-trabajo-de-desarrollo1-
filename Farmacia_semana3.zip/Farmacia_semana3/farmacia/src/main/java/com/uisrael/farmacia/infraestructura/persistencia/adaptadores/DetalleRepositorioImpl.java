package com.uisrael.farmacia.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Detalle;
import com.uisrael.farmacia.dominio.repositorios.IDetalleRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.DetalleEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IDetalleJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.IDetalleJpaRepositorio;

public class DetalleRepositorioImpl implements IDetalleRepositorio{
	private final IDetalleJpaRepositorio jpaRepositorio;
	private final IDetalleJpaMaper entityMapper;
	
	
	
	public DetalleRepositorioImpl(IDetalleJpaRepositorio jpaRepositorio, IDetalleJpaMaper entityMapper) {
		super();
		this.jpaRepositorio = jpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Detalle guardar(Detalle detalle) {
		DetalleEntity entity = entityMapper.toEntity(detalle);
		DetalleEntity guardardo = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardardo);
	}

	@Override
	public Optional<Detalle> busarPorId(int id) {
		// TODO Auto-generated method stub
		return jpaRepositorio.findById(id).map(entityMapper::toDomain);
	}

	@Override
	public List<Detalle> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int id) {
		jpaRepositorio.deleteById(id);
		
	}

}
