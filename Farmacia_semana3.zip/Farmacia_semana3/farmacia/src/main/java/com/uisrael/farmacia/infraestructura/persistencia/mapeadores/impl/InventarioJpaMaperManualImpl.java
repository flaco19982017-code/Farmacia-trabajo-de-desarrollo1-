package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Inventario;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.InventarioEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IInventarioJpaMaper;

@Primary
@Component
public class InventarioJpaMaperManualImpl implements IInventarioJpaMaper {

	@Override
	public Inventario toDomain(InventarioEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Inventario(entity.getIdInventario(), entity.getIdFarmacia(), entity.getIdProducto(), entity.getStockActual(), entity.getStockMinimo());
	}

	@Override
	public InventarioEntity toEntity(Inventario inventarioPojo) {
		if (inventarioPojo == null) {
			return null;
		}
		InventarioEntity entity = new InventarioEntity();
		entity.setIdInventario(inventarioPojo.getIdInventario());
		entity.setIdFarmacia(inventarioPojo.getIdFarmacia());
		entity.setIdProducto(inventarioPojo.getIdProducto());
		entity.setStockActual(inventarioPojo.getStockActual());
		entity.setStockMinimo(inventarioPojo.getStockMinimo());
		return entity;
	}
}
