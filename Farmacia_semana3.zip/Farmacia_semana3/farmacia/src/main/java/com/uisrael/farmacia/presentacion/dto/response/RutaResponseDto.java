package com.uisrael.farmacia.presentacion.dto.response;

import java.time.LocalDateTime;

public class RutaResponseDto {
	private  int idRuta;

	private  int idPedido;
	private  int idVehiculo;
	private  int idUsuario;
	private  LocalDateTime fechaAsignacion;
	private  String estadoRuta;
	private  String observacion;
	public int getIdRuta() {
		return idRuta;
	}
	public void setIdRuta(int idRuta) {
		this.idRuta = idRuta;
	}
	public int getIdPedido() {
		return idPedido;
	}
	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}
	public int getIdVehiculo() {
		return idVehiculo;
	}
	public void setIdVehiculo(int idVehiculo) {
		this.idVehiculo = idVehiculo;
	}
	public int getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	public LocalDateTime getFechaAsignacion() {
		return fechaAsignacion;
	}
	public void setFechaAsignacion(LocalDateTime fechaAsignacion) {
		this.fechaAsignacion = fechaAsignacion;
	}
	public String getEstadoRuta() {
		return estadoRuta;
	}
	public void setEstadoRuta(String estadoRuta) {
		this.estadoRuta = estadoRuta;
	}
	public String getObservacion() {
		return observacion;
	}
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
}
