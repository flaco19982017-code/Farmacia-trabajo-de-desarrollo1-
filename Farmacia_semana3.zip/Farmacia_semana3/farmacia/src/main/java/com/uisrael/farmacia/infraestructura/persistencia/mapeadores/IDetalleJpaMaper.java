package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Detalle;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.DetalleEntity;
@Mapper(componentModel = "spring")
public interface IDetalleJpaMaper {
	Detalle toDomain(DetalleEntity entity);
	DetalleEntity toEntity(Detalle detallePojo);
}
