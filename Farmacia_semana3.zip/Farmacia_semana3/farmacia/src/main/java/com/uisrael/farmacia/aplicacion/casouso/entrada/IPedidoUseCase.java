package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;


import com.uisrael.farmacia.dominio.entidades.Pedido;

public interface IPedidoUseCase {
	Pedido guardar(Pedido pedido);

	Pedido busarPorId(int id);

	List<Pedido> listarTodos();

	void eliminar(int id);
}
