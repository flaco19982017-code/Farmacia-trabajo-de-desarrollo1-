package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Laboratorio;

public interface ILaboratorioRepositorio {
	Laboratorio guardar(Laboratorio laboratorio);

	Optional<Laboratorio> busarPorId(int id);

	List<Laboratorio> listarTodos();

	void eliminar(int id);
}
