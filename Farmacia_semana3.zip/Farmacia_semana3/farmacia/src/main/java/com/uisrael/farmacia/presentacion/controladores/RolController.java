package com.uisrael.farmacia.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IRolUseCase;
import com.uisrael.farmacia.presentacion.dto.request.RolRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.RolResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IRolDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/rol")
public class RolController {
	 private final IRolUseCase rolUseCase;
	    private final IRolDtoMapper mapper;

	    public RolController(IRolUseCase rolUseCase, IRolDtoMapper mapper) {
	        this.rolUseCase = rolUseCase;
	        this.mapper = mapper;
	    }

	    @PostMapping
	    @ResponseStatus(HttpStatus.CREATED)
	    public RolResponseDto guardar(@Valid @RequestBody RolRequestDto rolRequestDto) {
	        return mapper.toResponseDto(
	                rolUseCase.guardar(
	                        mapper.toDomain(rolRequestDto)
	                )
	        );
	    }

	    @GetMapping
	    public List<RolResponseDto> listarTodo() {
	        return rolUseCase.listarTodos()
	                .stream()
	                .map(mapper::toResponseDto)
	                .toList();
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> eliminar(@PathVariable int id) {
	        rolUseCase.eliminar(id);
	        return ResponseEntity.noContent().build();
	    }
}
