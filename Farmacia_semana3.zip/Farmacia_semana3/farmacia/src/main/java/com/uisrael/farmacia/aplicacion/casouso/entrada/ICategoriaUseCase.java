package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;


import com.uisrael.farmacia.dominio.entidades.Categoria;


public interface ICategoriaUseCase {
	Categoria guardar(Categoria categoria);
    Categoria busarPorId(int id); 
	List<Categoria> listarTodos(); 
	void eliminar(int id);
}
