package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Ruta;
import com.uisrael.farmacia.presentacion.dto.request.RutaRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.RutaResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IRutaDtoMapper;

@Primary
@Component
public class RutaDtoMapperManualImpl implements IRutaDtoMapper {

	@Override
	public Ruta toDomain(RutaRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Ruta(dto.getIdRuta(), dto.getIdPedido(), dto.getIdVehiculo(), dto.getIdUsuario(), dto.getFechaAsignacion(), dto.getEstadoRuta(), dto.getObservacion());
	}

	@Override
	public RutaResponseDto toResponseDto(Ruta ruta) {
		if (ruta == null) {
			return null;
		}
		RutaResponseDto dto = new RutaResponseDto();
		dto.setIdRuta(ruta.getIdRuta());
		dto.setIdPedido(ruta.getIdPedido());
		dto.setIdVehiculo(ruta.getIdVehiculo());
		dto.setIdUsuario(ruta.getIdUsuario());
		dto.setFechaAsignacion(ruta.getFechaAsignacion());
		dto.setEstadoRuta(ruta.getEstadoRuta());
		dto.setObservacion(ruta.getObservacion());
		return dto;
	}
}
