package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Pedido;
import com.uisrael.farmacia.presentacion.dto.request.PedidoRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.PedidoResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IPedidoDtoMapper;

@Primary
@Component
public class PedidoDtoMapperManualImpl implements IPedidoDtoMapper {

	@Override
	public Pedido toDomain(PedidoRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Pedido(dto.getIdPedido(), dto.getIdCliente(), dto.getIdFarmacia(), dto.getFechaPedido(), dto.getEstadoPedido(), dto.getTotal());
	}

	@Override
	public PedidoResponseDto toResponseDto(Pedido pedido) {
		if (pedido == null) {
			return null;
		}
		PedidoResponseDto dto = new PedidoResponseDto();
		dto.setIdPedido(pedido.getIdPedido());
		dto.setIdCliente(pedido.getIdCliente());
		dto.setIdFarmacia(pedido.getIdFarmacia());
		dto.setFechaPedido(pedido.getFechaPedido());
		dto.setEstadoPedido(pedido.getEstadoPedido());
		dto.setTotal(pedido.getTotal());
		return dto;
	}
}
