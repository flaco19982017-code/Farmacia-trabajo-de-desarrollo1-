package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Vehiculo;
import com.uisrael.farmacia.presentacion.dto.request.VehiculoRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.VehiculoResponseDto;

@Mapper(componentModel = "spring")
public interface IVehiculoDtoMapper {
	Vehiculo toDomain(VehiculoRequestDto dto);

	VehiculoResponseDto toResponseDto(Vehiculo vehiculo);
}
