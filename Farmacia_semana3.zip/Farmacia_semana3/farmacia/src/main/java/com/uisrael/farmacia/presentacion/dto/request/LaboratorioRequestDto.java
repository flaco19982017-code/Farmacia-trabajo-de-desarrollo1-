package com.uisrael.farmacia.presentacion.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class LaboratorioRequestDto {
	private  int idLaboratorio;
@NotBlank
	private  String nombreLaboratorio;
@NotBlank
	private  String ruc;
@NotBlank
	private  String telefono;
@NotBlank
	private  String direccion;
}
