package com.uisrael.farmacia.presentacion.controladores;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IFarmaciaUseCase;
import com.uisrael.farmacia.presentacion.dto.request.FarmaciaRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.FarmaciaResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IFarmaciaDtoMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/farmacia")
public class FarmaciaController {
	 private final IFarmaciaUseCase farmaciaUseCase;
	    private final IFarmaciaDtoMapper mapper;

	    public FarmaciaController(IFarmaciaUseCase farmaciaUseCase, IFarmaciaDtoMapper mapper) {
	        this.farmaciaUseCase = farmaciaUseCase;
	        this.mapper = mapper;
	    }

	    @PostMapping
	    @ResponseStatus(HttpStatus.CREATED)
	    public FarmaciaResponseDto guardar(@Valid @RequestBody FarmaciaRequestDto farmaciaRequestDto) {
	        return mapper.toResponseDto(
	                farmaciaUseCase.guardar(
	                        mapper.toDomain(farmaciaRequestDto)
	                )
	        );
	    }

	    @GetMapping
	    public List<FarmaciaResponseDto> listarTodo() {
	        return farmaciaUseCase.listarTodos()
	                .stream()
	                .map(mapper::toResponseDto)
	                .toList();
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> eliminar(@PathVariable int id) {
	        farmaciaUseCase.eliminar(id);
	        return ResponseEntity.noContent().build();
	    }
}
