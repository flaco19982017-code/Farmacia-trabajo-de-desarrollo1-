package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IFarmaciaUseCase;
import com.uisrael.farmacia.dominio.entidades.Farmacia;
import com.uisrael.farmacia.dominio.repositorios.IFarmaciaRepositorio;

public class FarmaciaUseCaseImpl implements IFarmaciaUseCase {
	private final IFarmaciaRepositorio repositorio;

	public FarmaciaUseCaseImpl(IFarmaciaRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Farmacia guardar(Farmacia farmacia) {
		return repositorio.guardar(farmacia);
	}

	@Override
	public Farmacia busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("farmacia no encontrada"));
	}

	@Override
	public List<Farmacia> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
	}
}