package com.uisrael.farmacia.infraestructura.configuracion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.uisrael.farmacia.aplicacion.casouso.entrada.ICategoriaUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.IClienteUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.IDetalleUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.IFarmaciaUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.IInventarioUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.ILaboratorioUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.IMovimientoUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.IPedidoUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.IProductoUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.IRolUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.IRutaUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.IUsuarioUseCase;
import com.uisrael.farmacia.aplicacion.casouso.entrada.IVehiculoUseCase;
import com.uisrael.farmacia.aplicacion.casouso.impl.CategoriaUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.ClienteUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.DetalleUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.FarmaciaUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.InventarioUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.LaboratorioUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.MovimientoUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.PedidoUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.ProductoUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.RolUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.RutaUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.UsuarioUseCaseImpl;
import com.uisrael.farmacia.aplicacion.casouso.impl.VehiculoUseCaseImpl;
import com.uisrael.farmacia.dominio.repositorios.ICategoriaRepositorio;
import com.uisrael.farmacia.dominio.repositorios.IClienteRepositorio;
import com.uisrael.farmacia.dominio.repositorios.IDetalleRepositorio;
import com.uisrael.farmacia.dominio.repositorios.IFarmaciaRepositorio;
import com.uisrael.farmacia.dominio.repositorios.IInventarioRepositorio;
import com.uisrael.farmacia.dominio.repositorios.ILaboratorioRepositorio;
import com.uisrael.farmacia.dominio.repositorios.IMovimientoRepositorio;
import com.uisrael.farmacia.dominio.repositorios.IPedidoRepositorio;
import com.uisrael.farmacia.dominio.repositorios.IProductoRepositorio;
import com.uisrael.farmacia.dominio.repositorios.IRolRepositorio;
import com.uisrael.farmacia.dominio.repositorios.IRutaRepositorio;
import com.uisrael.farmacia.dominio.repositorios.IUsuarioRepositorio;
import com.uisrael.farmacia.dominio.repositorios.IVehiculoRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.CategoriaRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.ClienteRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.DetalleRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.FarmaciaRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.InventarioRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.LaboratorioRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.MovimientoRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.PedidoRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.ProductoRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.RolRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.RutaRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.UsuarioRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.adaptadores.VehiculoRepositorioImpl;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.ICategoriaJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IClienteJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IDetalleJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IFarmaciaJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IInventarioJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.ILaboratorioJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IMovimientoJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IPedidoJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IProductoJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IRolJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IRutaJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IUsuarioJpaMaper;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IVehiculoJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.ICategoriaJpaRepositorio;
import com.uisrael.farmacia.infraestructura.repositorios.IClienteJpaRespositorio;
import com.uisrael.farmacia.infraestructura.repositorios.IDetalleJpaRepositorio;
import com.uisrael.farmacia.infraestructura.repositorios.IFarmaciaJpaRepositorio;
import com.uisrael.farmacia.infraestructura.repositorios.IInventarioJpaRepositorio;
import com.uisrael.farmacia.infraestructura.repositorios.ILaboratorioJpaRepositorio;
import com.uisrael.farmacia.infraestructura.repositorios.IMovimientoJpaRepositorio;
import com.uisrael.farmacia.infraestructura.repositorios.IPedidoJpaRepositorio;
import com.uisrael.farmacia.infraestructura.repositorios.IProductoJpaRepositorio;
import com.uisrael.farmacia.infraestructura.repositorios.IRolJpaRepositorio;
import com.uisrael.farmacia.infraestructura.repositorios.IRutaJpaRepositorio;
import com.uisrael.farmacia.infraestructura.repositorios.IUsuarioJpaRepositorio;
import com.uisrael.farmacia.infraestructura.repositorios.IVehiculoJpaRepositorio;

@Configuration
public class Farmaciaconfig {
	 @Bean
	    ICategoriaRepositorio categoriaRepositorio(ICategoriaJpaRepositorio jpaRepositorio, ICategoriaJpaMaper mapper) {
	        return new CategoriaRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    ICategoriaUseCase categoriaUseCase(ICategoriaRepositorio repositorio) {
	        return new CategoriaUseCaseImpl(repositorio);
	    }

	    @Bean
	    IClienteRepositorio clienteRepositorio(IClienteJpaRespositorio jpaRepositorio, IClienteJpaMaper mapper) {
	        return new ClienteRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    IClienteUseCase clienteUseCase(IClienteRepositorio repositorio) {
	        return new ClienteUseCaseImpl(repositorio);
	    }

	    @Bean
	    IDetalleRepositorio detalleRepositorio(IDetalleJpaRepositorio jpaRepositorio, IDetalleJpaMaper mapper) {
	        return new DetalleRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    IDetalleUseCase detalleUseCase(IDetalleRepositorio repositorio) {
	        return new DetalleUseCaseImpl(repositorio);
	    }

	    @Bean
	    IFarmaciaRepositorio farmaciaRepositorio(IFarmaciaJpaRepositorio jpaRepositorio, IFarmaciaJpaMaper mapper) {
	        return new FarmaciaRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    IFarmaciaUseCase farmaciaUseCase(IFarmaciaRepositorio repositorio) {
	        return new FarmaciaUseCaseImpl(repositorio);
	    }

	    @Bean
	    IInventarioRepositorio inventarioRepositorio(IInventarioJpaRepositorio jpaRepositorio, IInventarioJpaMaper mapper) {
	        return new InventarioRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    IInventarioUseCase inventarioUseCase(IInventarioRepositorio repositorio) {
	        return new InventarioUseCaseImpl(repositorio);
	    }

	    @Bean
	    ILaboratorioRepositorio laboratorioRepositorio(ILaboratorioJpaRepositorio jpaRepositorio, ILaboratorioJpaMaper mapper) {
	        return new LaboratorioRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    ILaboratorioUseCase laboratorioUseCase(ILaboratorioRepositorio repositorio) {
	        return new LaboratorioUseCaseImpl(repositorio);
	    }

	    @Bean
	    IMovimientoRepositorio movimientoRepositorio(IMovimientoJpaRepositorio jpaRepositorio, IMovimientoJpaMaper mapper) {
	        return new MovimientoRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    IMovimientoUseCase movimientoUseCase(IMovimientoRepositorio repositorio) {
	        return new MovimientoUseCaseImpl(repositorio);
	    }

	    @Bean
	    IPedidoRepositorio pedidoRepositorio(IPedidoJpaRepositorio jpaRepositorio, IPedidoJpaMaper mapper) {
	        return new PedidoRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    IPedidoUseCase pedidoUseCase(IPedidoRepositorio repositorio) {
	        return new PedidoUseCaseImpl(repositorio);
	    }

	    @Bean
	    IProductoRepositorio productoRepositorio(IProductoJpaRepositorio jpaRepositorio, IProductoJpaMaper mapper) {
	        return new ProductoRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    IProductoUseCase productoUseCase(IProductoRepositorio repositorio) {
	        return new ProductoUseCaseImpl(repositorio);
	    }

	    @Bean
	    IRolRepositorio rolRepositorio(IRolJpaRepositorio jpaRepositorio, IRolJpaMaper mapper) {
	        return new RolRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    IRolUseCase rolUseCase(IRolRepositorio repositorio) {
	        return new RolUseCaseImpl(repositorio);
	    }

	    @Bean
	    IRutaRepositorio rutaRepositorio(IRutaJpaRepositorio jpaRepositorio, IRutaJpaMaper mapper) {
	        return new RutaRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    IRutaUseCase rutaUseCase(IRutaRepositorio repositorio) {
	        return new RutaUseCaseImpl(repositorio);
	    }

	    @Bean
	    IUsuarioRepositorio usuarioRepositorio(IUsuarioJpaRepositorio jpaRepositorio, IUsuarioJpaMaper mapper) {
	        return new UsuarioRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    IUsuarioUseCase usuarioUseCase(IUsuarioRepositorio repositorio) {
	        return new UsuarioUseCaseImpl(repositorio);
	    }

	    @Bean
	    IVehiculoRepositorio vehiculoRepositorio(IVehiculoJpaRepositorio jpaRepositorio, IVehiculoJpaMaper mapper) {
	        return new VehiculoRepositorioImpl(jpaRepositorio, mapper);
	    }

	    @Bean
	    IVehiculoUseCase vehiculoUseCase(IVehiculoRepositorio repositorio) {
	        return new VehiculoUseCaseImpl(repositorio);
	    }
}
