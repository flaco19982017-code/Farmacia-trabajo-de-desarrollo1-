package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Laboratorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.LaboratorioEntity;
@Mapper(componentModel = "spring")
public interface ILaboratorioJpaMaper {
	Laboratorio toDomain(LaboratorioEntity entity);
	LaboratorioEntity toEntity(Laboratorio laboratorioPojo);
}
