package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Cliente;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.ClienteEntity;
@Mapper(componentModel = "spring")
public interface IClienteJpaMaper {
	Cliente toDomain(ClienteEntity entity);
	ClienteEntity toEntity(Cliente clientePojo);
}
