package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;

public class Usuario  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private  int idUsuario;

	private  int idRol;
	private  String nombre;
	private  String correo;
	private  String clave;
	private  boolean estado;
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	public void setIdRol(int idRol) {
		this.idRol = idRol;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public void setClave(String clave) {
		this.clave = clave;
	}
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	public Usuario(int idUsuario, int idRol, String nombre, String correo, String clave, boolean estado) {
	
		this.idUsuario = idUsuario;
		this.idRol = idRol;
		this.nombre = nombre;
		this.correo = correo;
		this.clave = clave;
		this.estado = estado;
	}
	public int getIdUsuario() {
		return idUsuario;
	}
	public int getIdRol() {
		return idRol;
	}
	public String getNombre() {
		return nombre;
	}
	public String getCorreo() {
		return correo;
	}
	public String getClave() {
		return clave;
	}
	public boolean isEstado() {
		return estado;
	}
	
}
