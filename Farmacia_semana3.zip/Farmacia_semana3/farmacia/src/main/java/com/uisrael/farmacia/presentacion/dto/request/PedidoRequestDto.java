package com.uisrael.farmacia.presentacion.dto.request;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class PedidoRequestDto {
	private  int idPedido;
@NotBlank
	private  int idCliente;
@NotBlank
	private  int idFarmacia;
@NotBlank
	private  LocalDateTime fechaPedido;
@NotBlank
	private  String estadoPedido;
@NotBlank
	private  BigDecimal total;
}
