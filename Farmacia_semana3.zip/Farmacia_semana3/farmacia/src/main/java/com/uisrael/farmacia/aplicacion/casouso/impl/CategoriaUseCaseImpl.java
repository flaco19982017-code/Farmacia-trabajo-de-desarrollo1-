package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.ICategoriaUseCase;
import com.uisrael.farmacia.dominio.entidades.Categoria;
import com.uisrael.farmacia.dominio.repositorios.ICategoriaRepositorio;

public class CategoriaUseCaseImpl implements ICategoriaUseCase{
	private final ICategoriaRepositorio repositorio;
	public CategoriaUseCaseImpl(ICategoriaRepositorio repositorio) {
		
		this.repositorio = repositorio;
	}
	
	@Override
	public Categoria guardar(Categoria categoria) {
		// TODO Auto-generated method stub
		return repositorio.guardar(categoria);
	}

	@Override
	public Categoria busarPorId(int id) {
		// TODO Auto-generated method stub
		return  repositorio.busarPorId(id).orElseThrow(()->  new RuntimeException("categoria no encontrado"));
	}

	@Override
	public List<Categoria> listarTodos() {
		// TODO Auto-generated method stub
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		// TODO Auto-generated method stub
		repositorio.eliminar(id);
	}

}
