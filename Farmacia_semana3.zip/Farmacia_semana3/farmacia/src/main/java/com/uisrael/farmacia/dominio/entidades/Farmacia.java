package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;

public class Farmacia implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private  int idFarmacia;

	private  String nombre;
	private  String direccion;
	private  String zona;
	private  boolean estado;
	public Farmacia(int idFarmacia, String nombre, String direccion, String zona, boolean estado) {
	
		this.idFarmacia = idFarmacia;
		this.nombre = nombre;
		this.direccion = direccion;
		this.zona = zona;
		this.estado = estado;
	}
	public int getIdFarmacia() {
		return idFarmacia;
	}
	public String getNombre() {
		return nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public String getZona() {
		return zona;
	}
	public boolean isEstado() {
		return estado;
	}
	public void setIdFarmacia(int idFarmacia) {
		this.idFarmacia = idFarmacia;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public void setZona(String zona) {
		this.zona = zona;
	}
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	
}
