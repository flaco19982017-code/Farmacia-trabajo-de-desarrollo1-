package com.uisrael.farmacia.aplicacion.casouso.entrada;

import java.util.List;


import com.uisrael.farmacia.dominio.entidades.Detalle;

public interface IDetalleUseCase {
	Detalle guardar(Detalle detalle);

	Detalle busarPorId(int id);

	List<Detalle> listarTodos();

	void eliminar(int id);
}
