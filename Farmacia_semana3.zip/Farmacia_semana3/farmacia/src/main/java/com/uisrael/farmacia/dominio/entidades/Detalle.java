package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;
import java.math.BigDecimal;

public class Detalle implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private  int idDetalle;

	private  int idPedido;
	private  int idProducto;
	private  int cantidad;
	private  BigDecimal precioUnitario;
	private  BigDecimal subtotal;
	public Detalle(int idDetalle, int idPedido, int idProducto, int cantidad, BigDecimal precioUnitario,
			BigDecimal subtotal) {

		this.idDetalle = idDetalle;
		this.idPedido = idPedido;
		this.idProducto = idProducto;
		this.cantidad = cantidad;
		this.precioUnitario = precioUnitario;
		this.subtotal = subtotal;
	}
	public int getIdDetalle() {
		return idDetalle;
	}
	public int getIdPedido() {
		return idPedido;
	}
	public int getIdProducto() {
		return idProducto;
	}
	public int getCantidad() {
		return cantidad;
	}
	public BigDecimal getPrecioUnitario() {
		return precioUnitario;
	}
	public BigDecimal getSubtotal() {
		return subtotal;
	}
	public void setIdDetalle(int idDetalle) {
		this.idDetalle = idDetalle;
	}
	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}
	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	public void setPrecioUnitario(BigDecimal precioUnitario) {
		this.precioUnitario = precioUnitario;
	}
	public void setSubtotal(BigDecimal subtotal) {
		this.subtotal = subtotal;
	}
	
}
