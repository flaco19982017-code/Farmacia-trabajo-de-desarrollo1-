package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Movimiento;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.MovimientoEntity;
@Mapper(componentModel = "spring")
public interface IMovimientoJpaMaper {
	Movimiento toDomain(MovimientoEntity entity);
	MovimientoEntity toEntity(Movimiento movimientoPojo);
}
