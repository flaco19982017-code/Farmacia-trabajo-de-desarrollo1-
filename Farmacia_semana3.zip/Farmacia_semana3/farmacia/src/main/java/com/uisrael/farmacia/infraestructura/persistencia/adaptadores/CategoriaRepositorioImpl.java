package com.uisrael.farmacia.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;



import com.uisrael.farmacia.dominio.entidades.Categoria;
import com.uisrael.farmacia.dominio.repositorios.ICategoriaRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.CategoriaEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.ICategoriaJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.ICategoriaJpaRepositorio;


public class CategoriaRepositorioImpl implements ICategoriaRepositorio{
	private final ICategoriaJpaRepositorio jpaRepositorio;
private final ICategoriaJpaMaper entityMapper;

	public CategoriaRepositorioImpl(ICategoriaJpaRepositorio jpaRepositorio, ICategoriaJpaMaper entityMapper) {
	super();
	this.jpaRepositorio = jpaRepositorio;
	this.entityMapper = entityMapper;
}

	@Override
	public Categoria guardar(Categoria categoria) {
		CategoriaEntity entity=entityMapper.toEntity(categoria);
		CategoriaEntity guardardo=jpaRepositorio.save(entity);
		// TODO Auto-generated method stub
		return entityMapper.toDomain(guardardo);
		
	}

	@Override
	public Optional<Categoria> busarPorId(int id) {
		// TODO Auto-generated method stub
		return jpaRepositorio.findById(id).map(entityMapper :: toDomain);
	}

	@Override
	public List<Categoria> listarTodos() {
		// TODO Auto-generated method stub
		return jpaRepositorio.findAll().stream().map(entityMapper :: toDomain).toList();
	}

	@Override
	public void eliminar(int id) {
		// TODO Auto-generated method stub
		jpaRepositorio.deleteById(id);
	}
	
}
