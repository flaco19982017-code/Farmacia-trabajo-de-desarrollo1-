package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Rol;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.RolEntity;
@Mapper(componentModel = "spring")
public interface IRolJpaMaper {
	Rol toDomain(RolEntity entity);
	RolEntity toEntity(Rol rolPojo);
}
