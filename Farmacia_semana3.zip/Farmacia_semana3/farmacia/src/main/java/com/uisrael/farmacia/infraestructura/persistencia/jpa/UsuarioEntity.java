package com.uisrael.farmacia.infraestructura.persistencia.jpa;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "usuario")
public class UsuarioEntity {
	;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  int idUsuario;

	private  int idRol;
	private  String nombre;
	private  String correo;
	private  String clave;
	private  boolean estado;
}
