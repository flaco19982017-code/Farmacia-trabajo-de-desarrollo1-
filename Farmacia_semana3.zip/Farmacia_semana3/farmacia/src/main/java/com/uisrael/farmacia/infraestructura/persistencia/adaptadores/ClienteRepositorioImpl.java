package com.uisrael.farmacia.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Cliente;
import com.uisrael.farmacia.dominio.repositorios.IClienteRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.ClienteEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IClienteJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.IClienteJpaRespositorio;


public class ClienteRepositorioImpl implements IClienteRepositorio {

	private final IClienteJpaRespositorio jpaRepositorio;
	private final IClienteJpaMaper entityMapper;

	public ClienteRepositorioImpl(IClienteJpaRespositorio jpaRepositorio, IClienteJpaMaper entityMapper) {
		super();
		this.jpaRepositorio = jpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Cliente guardar(Cliente cliente) {
		ClienteEntity entity = entityMapper.toEntity(cliente);
		ClienteEntity guardardo = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardardo);
	}

	@Override
	public Optional<Cliente> busarPorId(int id) {
		return jpaRepositorio.findById(id).map(entityMapper::toDomain);
	}

	@Override
	public List<Cliente> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int id) {
		jpaRepositorio.deleteById(id);
	}
}