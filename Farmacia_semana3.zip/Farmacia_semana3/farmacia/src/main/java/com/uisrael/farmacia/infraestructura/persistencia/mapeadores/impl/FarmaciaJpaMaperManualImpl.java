package com.uisrael.farmacia.infraestructura.persistencia.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Farmacia;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.FarmaciaEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IFarmaciaJpaMaper;

@Primary
@Component
public class FarmaciaJpaMaperManualImpl implements IFarmaciaJpaMaper {

	@Override
	public Farmacia toDomain(FarmaciaEntity entity) {
		if (entity == null) {
			return null;
		}
		return new Farmacia(entity.getIdFarmacia(), entity.getNombre(), entity.getDireccion(), entity.getZona(), entity.isEstado());
	}

	@Override
	public FarmaciaEntity toEntity(Farmacia farmaciaPojo) {
		if (farmaciaPojo == null) {
			return null;
		}
		FarmaciaEntity entity = new FarmaciaEntity();
		entity.setIdFarmacia(farmaciaPojo.getIdFarmacia());
		entity.setNombre(farmaciaPojo.getNombre());
		entity.setDireccion(farmaciaPojo.getDireccion());
		entity.setZona(farmaciaPojo.getZona());
		entity.setEstado(farmaciaPojo.isEstado());
		return entity;
	}
}
