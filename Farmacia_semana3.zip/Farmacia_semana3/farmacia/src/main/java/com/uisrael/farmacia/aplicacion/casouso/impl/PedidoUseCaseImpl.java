package com.uisrael.farmacia.aplicacion.casouso.impl;

import java.util.List;

import com.uisrael.farmacia.aplicacion.casouso.entrada.IPedidoUseCase;
import com.uisrael.farmacia.dominio.entidades.Pedido;
import com.uisrael.farmacia.dominio.repositorios.IPedidoRepositorio;

public class PedidoUseCaseImpl implements IPedidoUseCase {
	private final IPedidoRepositorio repositorio;

	public PedidoUseCaseImpl(IPedidoRepositorio repositorio) {
		this.repositorio = repositorio;
	}

	@Override
	public Pedido guardar(Pedido pedido) {
		return repositorio.guardar(pedido);
	}

	@Override
	public Pedido busarPorId(int id) {
		return repositorio.busarPorId(id).orElseThrow(() -> new RuntimeException("pedido no encontrado"));
	}

	@Override
	public List<Pedido> listarTodos() {
		return repositorio.listarTodos();
	}

	@Override
	public void eliminar(int id) {
		repositorio.eliminar(id);
	}
}