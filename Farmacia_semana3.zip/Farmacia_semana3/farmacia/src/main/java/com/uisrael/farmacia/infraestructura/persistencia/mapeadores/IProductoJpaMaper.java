package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Producto;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.ProductoEntity;

@Mapper(componentModel = "spring")
public interface IProductoJpaMaper {
	Producto toDomain(ProductoEntity entity);
	ProductoEntity toEntity(Producto productoPojo);
}
