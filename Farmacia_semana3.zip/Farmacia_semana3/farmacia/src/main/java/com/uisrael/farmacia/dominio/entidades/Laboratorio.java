package com.uisrael.farmacia.dominio.entidades;

import java.io.Serializable;

public class Laboratorio implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private  int idLaboratorio;

	private  String nombreLaboratorio;
	private  String ruc;
	private  String telefono;
	private  String direccion;
	public Laboratorio(int idLaboratorio, String nombreLaboratorio, String ruc, String telefono, String direccion) {
		
		this.idLaboratorio = idLaboratorio;
		this.nombreLaboratorio = nombreLaboratorio;
		this.ruc = ruc;
		this.telefono = telefono;
		this.direccion = direccion;
	}
	public int getIdLaboratorio() {
		return idLaboratorio;
	}
	public String getNombreLaboratorio() {
		return nombreLaboratorio;
	}
	public String getRuc() {
		return ruc;
	}
	public String getTelefono() {
		return telefono;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setIdLaboratorio(int idLaboratorio) {
		this.idLaboratorio = idLaboratorio;
	}
	public void setNombreLaboratorio(String nombreLaboratorio) {
		this.nombreLaboratorio = nombreLaboratorio;
	}
	public void setRuc(String ruc) {
		this.ruc = ruc;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
}
