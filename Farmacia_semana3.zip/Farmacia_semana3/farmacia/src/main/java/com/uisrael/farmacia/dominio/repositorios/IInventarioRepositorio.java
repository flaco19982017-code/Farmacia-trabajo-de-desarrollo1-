package com.uisrael.farmacia.dominio.repositorios;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Inventario;

public interface IInventarioRepositorio {
	Inventario guardar(Inventario inventario);

	Optional<Inventario> busarPorId(int id);

	List<Inventario> listarTodos();

	void eliminar(int id);
}
