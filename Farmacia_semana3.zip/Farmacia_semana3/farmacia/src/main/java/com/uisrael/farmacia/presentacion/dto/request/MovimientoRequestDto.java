package com.uisrael.farmacia.presentacion.dto.request;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class MovimientoRequestDto {
	private  int idMovimiento;
@NotBlank
	private  int idInventario;
@NotBlank
	private  int idUsuario;
@NotBlank
	private  String tipoMovimiento;
@NotBlank
	private  int cantidad;
@NotBlank
	private  LocalDateTime fechaMovimiento;
@NotBlank
	private  String observacion;
}
