package com.uisrael.farmacia.infraestructura.persistencia.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Usuario;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.UsuarioEntity;
@Mapper(componentModel = "spring")
public interface IUsuarioJpaMaper {
	Usuario toDomain(UsuarioEntity entity);
	UsuarioEntity toEntity(Usuario usuarioPojo);
}
