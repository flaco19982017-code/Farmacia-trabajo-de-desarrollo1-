package com.uisrael.farmacia.infraestructura.persistencia.adaptadores;

import java.util.List;
import java.util.Optional;

import com.uisrael.farmacia.dominio.entidades.Pedido;
import com.uisrael.farmacia.dominio.repositorios.IPedidoRepositorio;
import com.uisrael.farmacia.infraestructura.persistencia.jpa.PedidoEntity;
import com.uisrael.farmacia.infraestructura.persistencia.mapeadores.IPedidoJpaMaper;
import com.uisrael.farmacia.infraestructura.repositorios.IPedidoJpaRepositorio;

public class PedidoRepositorioImpl implements IPedidoRepositorio {

	private final IPedidoJpaRepositorio jpaRepositorio;
	private final IPedidoJpaMaper entityMapper;

	public PedidoRepositorioImpl(IPedidoJpaRepositorio jpaRepositorio, IPedidoJpaMaper entityMapper) {
		super();
		this.jpaRepositorio = jpaRepositorio;
		this.entityMapper = entityMapper;
	}

	@Override
	public Pedido guardar(Pedido pedido) {
		PedidoEntity entity = entityMapper.toEntity(pedido);
		PedidoEntity guardardo = jpaRepositorio.save(entity);
		return entityMapper.toDomain(guardardo);
	}

	@Override
	public Optional<Pedido> busarPorId(int id) {
		return jpaRepositorio.findById(id).map(entityMapper::toDomain);
	}

	@Override
	public List<Pedido> listarTodos() {
		return jpaRepositorio.findAll().stream().map(entityMapper::toDomain).toList();
	}

	@Override
	public void eliminar(int id) {
		jpaRepositorio.deleteById(id);
	}
}