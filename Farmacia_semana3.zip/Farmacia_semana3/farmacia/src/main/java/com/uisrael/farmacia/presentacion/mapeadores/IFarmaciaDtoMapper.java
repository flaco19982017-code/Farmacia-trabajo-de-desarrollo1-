package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Farmacia;
import com.uisrael.farmacia.presentacion.dto.request.FarmaciaRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.FarmaciaResponseDto;

@Mapper(componentModel = "spring")
public interface IFarmaciaDtoMapper {
	Farmacia toDomain(FarmaciaRequestDto dto);

	FarmaciaResponseDto toResponseDto(Farmacia farmacia);
}
