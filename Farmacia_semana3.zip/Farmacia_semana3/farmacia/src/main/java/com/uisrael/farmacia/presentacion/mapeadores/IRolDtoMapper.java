package com.uisrael.farmacia.presentacion.mapeadores;

import org.mapstruct.Mapper;

import com.uisrael.farmacia.dominio.entidades.Rol;
import com.uisrael.farmacia.presentacion.dto.request.RolRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.RolResponseDto;

@Mapper(componentModel = "spring")
public interface IRolDtoMapper {
	Rol toDomain(RolRequestDto dto);

	RolResponseDto toResponseDto(Rol rol);
}
