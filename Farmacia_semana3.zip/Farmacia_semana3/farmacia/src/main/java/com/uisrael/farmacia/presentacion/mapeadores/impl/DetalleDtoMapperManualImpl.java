package com.uisrael.farmacia.presentacion.mapeadores.impl;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.uisrael.farmacia.dominio.entidades.Detalle;
import com.uisrael.farmacia.presentacion.dto.request.DetalleRequestDto;
import com.uisrael.farmacia.presentacion.dto.response.DetalleResponseDto;
import com.uisrael.farmacia.presentacion.mapeadores.IDetalleDtoMapper;

@Primary
@Component
public class DetalleDtoMapperManualImpl implements IDetalleDtoMapper {

	@Override
	public Detalle toDomain(DetalleRequestDto dto) {
		if (dto == null) {
			return null;
		}
		return new Detalle(dto.getIdDetalle(), dto.getIdPedido(), dto.getIdProducto(), dto.getCantidad(), dto.getPrecioUnitario(), dto.getSubtotal());
	}

	@Override
	public DetalleResponseDto toResponseDto(Detalle detalle) {
		if (detalle == null) {
			return null;
		}
		DetalleResponseDto dto = new DetalleResponseDto();
		dto.setIdDetalle(detalle.getIdDetalle());
		dto.setIdPedido(detalle.getIdPedido());
		dto.setIdProducto(detalle.getIdProducto());
		dto.setCantidad(detalle.getCantidad());
		dto.setPrecioUnitario(detalle.getPrecioUnitario());
		dto.setSubtotal(detalle.getSubtotal());
		return dto;
	}
}
